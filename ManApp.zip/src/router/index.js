import { createWebHistory, createRouter } from "vue-router";
import SignIn from "@/components/auth/Login.vue";
import Register from "@/components/auth/Register.vue";

const authGuard = (to, from, next) => {
  var isAuthenticated = false;
  if (localStorage.getItem("token")) isAuthenticated = true;
  else isAuthenticated = false;
  if (isAuthenticated) next();
  else next("/login");
};

const routes = [
  { path: "/", component: SignIn, meta: { title: "Sign In" } },
  { path: "/login", component: SignIn, meta: { title: "Sign In" } },
  { path: "/register", component: Register, meta: { title: 'Register' } },
  { path: "/dashboard", component: () => import("@/components/dashboard.vue"), beforeEnter: authGuard, meta: { title: "Dashboard" },},
  { path: "/products", component: () => import("@/components/admin/products.vue"), beforeEnter: authGuard, meta: { title: "Products" },},
  { path: "/products-attributes", component: () => import("@/components/admin/attributes.vue"), beforeEnter: authGuard, meta: { title: "Product Attributes" },},
  { path: "/categories", component: () => import("@/components/admin/productCategories.vue"), beforeEnter: authGuard, meta: { title: "Product Categories" },},
  { path: "/suppliers", component: () => import("@/components/admin/suppliers.vue"), beforeEnter: authGuard, meta: { title: "Suppliers" },},
  { path: "/cities", component: () => import("@/components/admin/cities.vue"), beforeEnter: authGuard, meta: { title: "Cities" },},
  { path: "/countries", component: () => import("@/components/admin/countries.vue"), beforeEnter: authGuard, meta: { title: "Countries" },},
  { path: "/counties", component: () => import("@/components/admin/counties.vue"), beforeEnter: authGuard, meta: { title: "Counties" },},
  { path: "/requests", component: () => import("@/components/admin/donationRequests.vue"), beforeEnter: authGuard, meta: { title: "Product Aid" },},
  { path: "/donations", component: () => import("@/components/admin/donations.vue"), beforeEnter: authGuard, meta: { title: "Donations" },},
  { path: "/donors", component: () => import("@/components/admin/donors.vue"), beforeEnter: authGuard, meta: { title: "Donors" },},
  { path: "/email-templates", component: () => import("@/components/admin/emailTemplates.vue"), beforeEnter: authGuard, meta: { title: "Email Templates" },},
  { path: "/faqs", component: () => import("@/components/admin/faqs.vue"), beforeEnter: authGuard, meta: { title: "FAQs" },},
  { path: "/logs", component: () => import("@/components/admin/logs.vue"), beforeEnter: authGuard, meta: { title: "System Logs" },},
  { path: "/members", component: () => import("@/components/admin/members.vue"), beforeEnter: authGuard, meta: { title: "Members" },},
  { path: "/payment-options", component: () => import("@/components/admin/paymentOptions.vue"), beforeEnter: authGuard, meta: { title: "Payment Options" },},
  { path: "/settings", component: () => import("@/components/admin/settings.vue"), beforeEnter: authGuard, meta: { title: "System Settings" },},
  { path: "/taxes", component: () => import("@/components/admin/taxes.vue"), beforeEnter: authGuard, meta: { title: "Taxes" },},
  { path: "/admins", component: () => import("@/components/admin/users.vue"), beforeEnter: authGuard, meta: { title: "Admins" },},
  { path: "/fundraise", component: () => import("@/components/admin/fundraising.vue"), beforeEnter: authGuard, meta: { title: "Fundraise" },},

  //common routes  @/components/requestLanding.vue
  { path: "/donation-requests", component: () => import("@/components/requestLanding.vue"), beforeEnter: authGuard, meta: { title: "Request landing" },},
  { path: "/profile", component: () => import("@/components/profile.vue"), beforeEnter: authGuard, meta: { title: "Profile" },},
  { path: "/request-preview", component: () => import("@/components/fundraiserPreview.vue"), beforeEnter: authGuard, meta: { title: "Fundraiser Preview" },},
  //member routes
  { path: "/product-categories", component: () => import("@/components/member/productCategories.vue"), beforeEnter: authGuard, meta: { title: "Product Categories" },},
  { path: "/category-products", component: () => import("@/components/member/products.vue"), beforeEnter: authGuard, meta: { title: "Products by Categories" },},
  { path: "/product-cart", component: () => import("@/components/member/productCart.vue"), beforeEnter: authGuard, meta: { title: "Products Aid Cart" },},
  { path: "/product-preview", component: () => import("@/components/member/productPreview.vue"), beforeEnter: authGuard, meta: { title: "Products Preview" },},
  { path: "/preview", component: () => import("@/components/member/preview.vue"), beforeEnter: authGuard, meta: { title: "Preview" },},
  { path: "/my-donation-requests", component: () => import("@/components/member/donationRequests.vue"), beforeEnter: authGuard, meta: { title: "My Product Aid" },},
  { path: "/my-fundraisers-requests", component: () => import("@/components/member/fundraisers.vue"), beforeEnter: authGuard, meta: { title: "My Fundraiser"},},
  //donor routes  
  { path: "/my-donations", component: () => import("@/components/donor/donations.vue"), beforeEnter: authGuard, meta: { title: "My Donations" },},
  { path: "/all-requests", component: () => import("@/components/donor/productRequests.vue"), beforeEnter: authGuard, meta: { title: "Product Aid" },},
  { path: "/gift-aid-preview", component: () => import("@/components/donor/preview.vue"), beforeEnter: authGuard, meta: { title: "Gift Aid Preview" },},
  { path: "/all-fundraisers", component: () => import("@/components/donor/fundraisers.vue"), beforeEnter: authGuard, meta: { title: "Fundraiser" },},
  { path: "/donation-cart", component: () => import("@/components/donor/cart.vue"), beforeEnter: authGuard, meta: { title: "Donation Cart" },},
  
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
