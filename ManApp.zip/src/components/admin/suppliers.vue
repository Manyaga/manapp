<template>
  <!-- Add Supplier Modal -->
  <div class="modal fade" id="verifyModalContent" tabindex="-1" role="dialog" aria-labelledby="verifyModalContent"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="verifyModalContent_title">Add Supplier</h5>
          <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <Form @submit="addSupplier" :validation-schema="schema" class="user">
          <div class="modal-body">
            <div class="row row-xs">
              <div class="form-group col-md-6">
                <label class="col-form-label" for="supplier_name">Supplier Name:</label>
                <Field name="supplier_name" class="form-control" id="supplier_name" type="text" placeholder="supplier name" />
                <ErrorMessage name="supplier_name" class="text-danger p-3" />
              </div>
              <div class="form-group col-md-6">
                <label class="col-form-label" for="phoneNumber">Phone Number:</label>
                <Field name="phoneNumber" class="form-control" id="phoneNumber" type="text" placeholder="Phone number" />
                <ErrorMessage name="phoneNumber" class="text-danger p-3" />
              </div>
              <div class="form-group col-md-6">
                <label class="col-form-label" for="email">Email:</label>
                <Field name="email" class="form-control" id="email" type="text" placeholder="Email" />
                <ErrorMessage name="email" class="text-danger p-3" />
              </div>
              <div class="form-group col-md-6">
                <label class="col-form-label" for="postalCode">Postal Code:</label>
                <Field name="postalCode" class="form-control" id="postalCode" type="text" placeholder="postal code" />
                <ErrorMessage name="postalCode" class="text-danger p-3" />
              </div>
              <div class="form-group col-md-6">
                <label class="col-form-label" for="street">Street:</label>
                <Field name="street" class="form-control" id="street" type="text" placeholder="Street" />
                <ErrorMessage name="street" class="text-danger p-3" />
              </div>
              <div class="form-group col-md-6"><label for="categoryId" class="form-control-label">Category Name</label>
                <Field name="category_id" class="form-control form-control-lg" v-model="category_id" as="select">
                  <option value="">-- Category--</option>
                  <option v-for="category in categories" :value="category._id" :key="category._id">
                    {{ category.category_name }}
                  </option>
                </Field>
                <ErrorMessage name="category_id" class="text-danger py-3 text-sm" />
              </div>
              <div class="form-group col-md-12">
                <label for="paymentId" class="form-control-label">Payment Name</label>
                <Field name="paymentId" class="form-control form-control-lg" v-model="paymentId" as="select">
                  <option value="">-- Payment--</option>
                  <option v-for="payment in payments" :value="payment._id" :key="payment._id">
                    {{ payment.payment_name }}
                  </option>
                </Field>
                <ErrorMessage name="paymentId" class="text-danger py-3 text-sm" />
              </div>
              <!-- <div class="form-group col-md-6">
                <label for="producttId" class="form-control-label">Product Name</label>
                <Field name="producttId" class="form-control form-control-lg" v-model="producttId" as="select">
                  <option value="">-- Product--</option>
                  <option v-for="product in products" :value="product._id" :key="product._id">
                    {{ product.product_name }}
                  </option>
                </Field>
                <ErrorMessage name="productId" class="text-danger py-3 text-sm" />
              </div> -->
          </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
            <button class="btn btn-primary" type="Submit">Submit</button>
          </div>
        </Form>
      </div>
    </div>
  </div>
  <!-- Edit Supplier Modal -->
  <div class="modal fade" id="editModalContent" tabindex="-1" role="dialog" aria-labelledby="editModalContent"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editModalContent_title">Edit Supplier</h5>
          <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        
        <Form @submit="editSupplier" :validation-schema="schema" class="user">
          <div class="modal-body">
            <div class="row">
              <div class="form-group col-md-6">
                <label class="col-form-label" for="supplier_name">Supplier Name:</label>
                <Field name="supplier_name" class="form-control" v-model="supplier_name" type="text" placeholder="supplier name" />
                <ErrorMessage name="supplier_name" class="text-danger p-3" />
              </div>
              <div class="form-group col-md-6">
                <label class="col-form-label" for="phoneNumber">Phone Number:</label>
                <Field name="phoneNumber" class="form-control" v-model="phoneNumber" type="text" placeholder="Phone number" />
                <ErrorMessage name="phoneNumber" class="text-danger p-3" />
              </div>
              <div class="form-group col-md-6">
                <label class="col-form-label" for="email">Email:</label>
                <Field name="email" class="form-control" v-model="email" type="text" placeholder="Email" />
                <ErrorMessage name="email" class="text-danger p-3" />
              </div>
              <div class="form-group col-md-6">
                <label class="col-form-label" for="postalCode">Postal Code:</label>
                <Field name="postalCode" class="form-control" v-model="postalCode" type="text" placeholder="postal code" />
                <ErrorMessage name="postalCode" class="text-danger p-3" />
              </div>
              <div class="form-group col-md-6">
                <label class="col-form-label" for="street">Street:</label>
                <Field name="street" class="form-control" v-model="street" type="text" placeholder="Street" />
                <ErrorMessage name="street" class="text-danger p-3" />
              </div>
              <div class="form-group col-md-6"><label for="categoryId" class="form-control-label">Category Name</label>
                <Field name="category_id" class="form-control form-control-lg" v-model="category_id" as="select">
                  <option value="">-- Category--</option>
                  <option v-for="category in categories" :value="category._id" :key="category._id">
                    {{ category.category_name }}
                  </option>
                </Field>
                <ErrorMessage name="category_id" class="text-danger py-3 text-sm" />
              </div>
              <div class="form-group col-md-12">
                <label for="paymentId" class="form-control-label">Payment Name</label>
                <Field name="paymentId" class="form-control form-control-lg" v-model="paymentId" as="select">
                  <option value="">-- Payment--</option>
                  <option v-for="payment in payments" :value="payment._id" :key="payment._id">
                    {{ payment.payment_name }}
                  </option>
                </Field>
                <ErrorMessage name="paymentId" class="text-danger py-3 text-sm" />
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
            <button class="btn btn-primary" type="Submit">Submit</button>
          </div>
        </Form>
      </div>
    </div>
  </div>
  <div class="app-admin-wrap layout-horizontal-bar">
    <Sidebar />
    <Topbar />
    <div class="main-content-wrap d-flex flex-column">
        <div class="main-content">
          <button class="btn btn-info text-white ul-btn-raised--v2 m-1  float-end" type="button" data-bs-toggle="modal"
                    data-target="#verifyModalContent" data-whatever="@mdo">
                    <i class="nav-icon i-add text-primary text-white fw-bold"></i> ADD SUPPLIER</button>
        <Breadcrumbs />
        <div class="separator-breadcrumb border-top"></div>
                  <div class="row mb-4">
                    <div class="col-md-12">
                            <div class="table-responsive">
                                <table class="table text-center" id="supplier_table">
                                <thead>
                                    <tr class="bg-primary text-white">
                                        <th scope="col">#</th>
                                        <th scope="col">Supplier</th>
                                        <th scope="col">Product Category</th>
                                        
                                        <th scope="col">Email</th>
                                        <th scope="col">Phone</th>
                                        <th scope="col">Payment Option</th>
                                        <!-- <th scope="col">Status</th> -->
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="(supplier,index) in suppliers" :key="supplier._id">
                                    <th scope="row">{{ index+1 }}</th>                                   
                                    <td>{{supplier.supplier_name.toUpperCase()}}</td>
                                    <td>{{supplier.category.category_name}}</td>
                                    <td>{{ supplier.email }}</td>
                                    <td>{{ supplier.phone_number }}</td>
                                    <td>{{ supplier.payment.payment_name }}</td>
                                    <!-- <td><span class="badge bg-success">Active</span>
                                    </td> -->
                                    <td>
                                    
                                        <a class="text-success me-2" href="#"  @click="openEditSupplier(supplier)"><i class="nav-icon i-Pen-2 fw-bold"></i></a>
                                        <a class="text-danger me-2" href="#" @click="deleteSupplier(supplier._id)"><i class="nav-icon i-Close-Window fw-bold"></i></a>
                                    </td>
                                    </tr>
                                </tbody>
                                </table>
                            </div>
                    </div>
                 </div>
      </div>
      <div class="flex-grow-1"></div>
      <Footer />
    </div>
  </div>
</template>
  
<script>
import Topbar from "@/components/partials/Topbar.vue";
import Footer from "@/components/partials/Footer.vue";
import Sidebar from "@/components/partials/Sidebar";
import Breadcrumbs from "@/components/partials/Breadcrumbs";
import "datatables.net-dt/js/dataTables.dataTables";
    import "@/assets/css/dataTables.bootstrap4.min.css";
    import "@/assets/css/buttons.dataTables.min.css";
    import "datatables.net-buttons/js/dataTables.buttons.js";
    import "datatables.net-buttons/js/buttons.colVis.js";
    import "datatables.net-buttons/js/buttons.flash.js";
    import "datatables.net-buttons/js/buttons.html5.js";
    import "datatables.net-buttons/js/buttons.print.js";
    import pdfMake from "pdfmake/build/pdfmake";
    import pdfFonts from "pdfmake/build/vfs_fonts";
    pdfMake.vfs = pdfFonts.pdfMake.vfs;

    import "@/assets/datatables/jquery.dataTables.min.js";
    import "@/assets/datatables/dataTables.bootstrap4.min.js";
    import "@/assets/datatables/dataTables.buttons.min.js";
    import "@/assets/datatables/buttons.html5.min.js";
    import "@/assets/datatables/buttons.print.min.js";
    import "@/assets/datatables/jszip.min.js";
import { Form, Field, ErrorMessage } from "vee-validate"
import * as yup from "yup"
import { ALL_SUPPLIERS_QUERY,ALL_PRODUCTS_QUERY, ALL_DONORS_QUERY,ALL_CATEGORIES_QUERY, ALL_PAYMENTS_QUERY,ADD_SUPPLIER_MUTATION, DELETE_SUPPLIER_MUTATION, EDIT_SUPPLIER_MUTATION } from '@/graphql'

export default {
  name: "Supplier",
  components: { Sidebar, Topbar, Footer, Breadcrumbs, Form, Field, ErrorMessage },
  data() {
    const schema = yup.object().shape({
      supplier_name: yup
        .string()
        .required("Supplier name is required!"),
        category_id: yup
        .string()
        .required("Category name is required!"),
        paymentId: yup
        .string()
        .required("Payment type is required!"),
    });
    return {
      suppliers: [],
      categories: [],
      payments: [],
      supplier_name: '',
      supplier_id: '',
      category_id: '',
      paymentId: '',
      phoneNumber: '',
      email: '',
      postalCode: '',
      productId: '',
      street: '',
      schema
    }
  },
  apollo: {
    categories: {
        query: ALL_CATEGORIES_QUERY
        },
    payments: {
        query: ALL_PAYMENTS_QUERY
        }
  },
  methods: {
    addSupplier(supplier) {
      console.log(supplier)
      this.$apollo
        .mutate({
          mutation: ADD_SUPPLIER_MUTATION,
          variables: {
            supplierName: supplier.supplier_name,
            paymentId: supplier.paymentId,
            categoryId: supplier.category_id,
            phoneNumber: supplier.phoneNumber,
            email: supplier.email,
            postalCode: supplier.postalCode,
            street: supplier.street,
            // productId: supplier.producttId,
          }
        })
        .then(response => {
          // redirect user
          $('#verifyModalContent').modal('hide')
          this.$swal({
            title: 'Supplier added sucessfully',
            position: 'top-end',
            icon: 'success',
            showConfirmButton: false,
            timer: 2000
          });
          this.$apollo.queries.suppliers.refetch()
        }).catch((error) => {
          this.$swal({
            title: error.message,
            position: "top-end",
            icon: "warning",
            showConfirmButton: false,
            timer: 3000,
          });
        })
    },
    openEditSupplier(supplier) {
      console.log(supplier)
      this.supplier_name = supplier.supplier_name
      this.supplier_id = supplier._id
      this.paymentId = supplier.payment._id
      this.phoneNumber =supplier.phone_number
      this.email = supplier.email
      this.postalCode = supplier.postal_code
      this.street = supplier.street
      this.category_id = supplier.category._id
      $('#editModalContent').modal('show')

    },
    editSupplier(supplier) {
      console.log(supplier)
      this.$apollo
        .mutate({
          mutation: EDIT_SUPPLIER_MUTATION,
          variables: {
            input: {
              id: this.supplier_id,
              supplier_name: supplier.supplier_name,
              payment: supplier.paymentId,
              email: supplier.email,
              phone_number: supplier.phoneNumber,
              postal_code: supplier.postalCode,
              street: supplier.street  
            }
          }
        })
        .then(response => {
          $('#editModalContent').modal('hide')
          this.$swal({
            title: 'supplier updated sucessfully',
            position: 'top-end',
            icon: 'success',
            showConfirmButton: false,
            timer: 2000
          });
          this.$apollo.queries.suppliers.refetch()
        }).catch((error) => {
          this.$swal({
            title: error.message,
            position: "top-end",
            icon: "warning",
            showConfirmButton: false,
            timer: 3000,
          });
        })
    },
    deleteSupplier(supplier_id) {
      this.$swal({
        title: "Delete the supplier?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
      }).then((result) => {
        if (result.isConfirmed) {
          this.$apollo
            .mutate({
              mutation: DELETE_SUPPLIER_MUTATION,
              variables: {
                supplierId: supplier_id,
              }
            })
            .then(response => {
              this.$swal({
                title: 'Supplier deleted sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
              });
              this.$apollo.queries.suppliers.refetch()
            }).catch((error) => {
              this.$swal({
                title: error.message,
                position: "top-end",
                icon: "warning",
                showConfirmButton: false,
                timer: 3000,
              });
            })
        }
      });
    },
    async statusChange(){      
        this.suppliers = [];       
        $('#supplier_table').DataTable().destroy();
        await this.$apollo.query({
            query: ALL_SUPPLIERS_QUERY,
            }).then(response => {
                this.suppliers = response.data.suppliers
            })
        setTimeout(function () {
            $("#supplier_table").DataTable({
                destroy: true,
                pageLength: 5,
                lengthChange: true,
                processing: true,
                paging: true,
                info: false,
                dom: "Bfrtip",
                buttons: [
                { extend: 'csv', text: '<i class="fa-solid fa-file-pdf"></i>', className: 'btn btn-sm btn-outline-success mb-3 text-success' },
                { extend: 'pdf', text: '<i class="fa fa-file-pdf"></i>', className: 'btn btn-sm btn-outline-danger mb-3 text-danger' },
                { extend: 'print', text: '<i class="fa fa-print"></i>', className: 'btn btn-sm btn-outline-secondary mb-3 text-secondary' }
                ]  
            });
            }, 300);
    }
  
  },
    async created(){
      this.statusChange();
    }
}
  </script>
  