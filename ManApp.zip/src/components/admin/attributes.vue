<template>
    <!-- Add Attribute Modal -->
    <div class="modal fade" id="verifyModalContent" tabindex="-1" role="dialog" aria-labelledby="verifyModalContent" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="verifyModalContent_title">Add Attribute</h5>
                                <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <Form @submit="addAttribute" :validation-schema="schema" class="user">
                                <div class="modal-body">
                                    
                                        <div class="form-group">
                                            <label class="col-form-label" for="attribute_name">Attribute Name:</label>
                                            <Field name="attribute_name" class="form-control" id="attribute_name" type="text" />
                                            <ErrorMessage name="attribute_name" class="text-danger p-3" />
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                    <button class="btn btn-primary" type="Submit">Submit</button>
                                </div>                            
                            </Form>
                        </div>
                    </div>
                </div>
     <!-- Edit Attribute Modal -->
     <div class="modal fade" id="editModalContent" tabindex="-1" role="dialog" aria-labelledby="editModalContent" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalContent_title">Edit Attribute {{ attribute_name}}</h5>
                                <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <Form @submit="editAttribute" :validation-schema="schema"  class="user">
                                <div class="modal-body">
                                    
                                        <div class="form-group">
                                            <label class="col-form-label" for="attribute_name">Attribute Name:</label>
                                            <Field name="attribute_name" class="form-control" v-model="attribute_name" type="text" />
                                            <ErrorMessage name="attribute_name" class="text-danger p-3" />
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                    <button class="btn btn-primary" type="Submit">Submit</button>
                                </div>                            
                            </Form>
                        </div>
                    </div>
                </div>
    <div class="app-admin-wrap layout-horizontal-bar">
    <Sidebar />
      <Topbar />
      <div class="main-content-wrap d-flex flex-column">
        <div class="main-content">
            <Breadcrumbs />
              <div class="separator-breadcrumb border-top"></div>
              <div class="row mb-4">
                <div class="col-md-12">
                    <button class="btn btn-info text-white ul-btn-raised--v2 m-1  float-end"
                            type="button" data-bs-toggle="modal" data-target="#verifyModalContent" data-whatever="@mdo">
                            <i class="nav-icon i-add text-primary text-white fw-bold"></i> ADD ATTRIBUTE</button>
                            
                  <p>Attributes are features that describe the services and product offered</p>
                  </div>
              </div>
                <div class="row mb-4">
                <div class="col-lg-3 col-xl-3 mt-3" v-for="attribute in attributes" :key="attribute._id">
                <div class="card">
                  <div class="card-body">
                    <div class="user-profile mb-4">
                      <div class="ul-widget-card__user-info">
                        <img
                          class="profile-picture avatar-lg mb-2"
                          src="https://cdn-icons-png.flaticon.com/512/9554/9554955.png"
                          alt=""
                        />
                        <p class="m-0 text-24">{{attribute.attribute_name.toUpperCase()}}</p>
                      </div>
                    </div>
                    <div class="mt-4">
                      <a class="text-info me-2" @click="openEditAttribute(attribute)"><i class="nav-icon i-Pen-2 fw-bold"></i></a>
                      <a class="text-danger me-2 float-end" @click="deleteAttribute(attribute._id)"><i class="nav-icon i-Close-Window fw-bold"></i></a>
                    </div>
                  </div>
                </div>
              </div>
                </div>
              </div>
          <div class="flex-grow-1"></div>
        <Footer />
      </div>
    </div>
  </template>
  
  <script>
  import Topbar from "@/components/partials/Topbar.vue";
  import Footer from "@/components/partials/Footer.vue";
  import Sidebar from "@/components/partials/Sidebar";
  import Breadcrumbs from "@/components/partials/Breadcrumbs";
  import { Form, Field, ErrorMessage } from "vee-validate"
  import * as yup from "yup"
  import { ALL_ATTRIBUTES_QUERY, ADD_ATTRIBUTE_MUTATION, DELETE_ATTRIBUTE_MUTATION,EDIT_ATTRIBUTE_MUTATION } from '@/graphql'
  export default {
    name: "Attribute",
    components: { Sidebar, Topbar, Footer, Breadcrumbs, Form, Field, ErrorMessage },
    data () {
    const schema = yup.object().shape({
        attribute_name: yup
          .string()
          .required("Attribute name is required!"),
    });
    return {
      attributes: [],
      attribute_name: '',
      attribute_id: '',
      schema
    }
  },
  apollo: {
    // fetch all attributes
    attributes: {
        query: ALL_ATTRIBUTES_QUERY
        }
    },
    methods: {
    addAttribute(attribute) {
      this.$apollo
        .mutate({
          mutation: ADD_ATTRIBUTE_MUTATION,
          variables: {
            attributeName: attribute.attribute_name,
          }
        })
        .then(response => {
          // redirect user
          $('#verifyModalContent').modal('hide')
            this.$swal({
                title: 'Attribute added sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
            });
            this.$apollo.queries.attributes.refetch()
        }).catch((error) => {
            this.$swal({
                title: error.message,
                position: "top-end",
                icon: "warning",
                showConfirmButton: false,
                timer: 3000,
            });
        })
      },
      openEditAttribute(attribute) {
        this.attribute_name = attribute.attribute_name
        this.attribute_id = attribute._id
        $('#editModalContent').modal('show')

      },
    editAttribute(attribute) {    
      console.log(attribute)    
      this.$apollo
        .mutate({
          mutation: EDIT_ATTRIBUTE_MUTATION,
          variables: {
            input: {
               id: this.attribute_id,
               attribute_name: attribute.attribute_name,
              }
          }
        })
        .then(response => {
          $('#editModalContent').modal('hide')
            this.$swal({
                title: 'attribute updated sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
            });
            this.$apollo.queries.attributes.refetch()
        }).catch((error) => {
            this.$swal({
                title: error.message,
                position: "top-end",
                icon: "warning",
                showConfirmButton: false,
                timer: 3000,
            });
        })
      },
      deleteAttribute(attribute_id) {
      this.$swal({
        title: "Delete the attributeattribute_id?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
      }).then((result) => {
        if (result.isConfirmed) {
            this.$apollo
                .mutate({
                mutation: DELETE_ATTRIBUTE_MUTATION,
                variables: {
                    attributeId: attribute_id,
                }
                })
                .then(response => {
                    this.$swal({
                        title: 'Attribute deleted sucessfully',
                        position: 'top-end',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    this.$apollo.queries.attributes.refetch()
                }).catch((error) => {
                    this.$swal({
                        title: error.message,
                        position: "top-end",
                        icon: "warning",
                        showConfirmButton: false,
                        timer: 3000,
                    });
                })
        }
      });
    },
  }  
  
  }
  </script>