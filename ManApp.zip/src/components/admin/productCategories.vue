<template>
    <div class="modal fade" id="verifyModalContent" tabindex="-1" role="dialog" aria-labelledby="verifyModalContent" aria-hidden="true">
                   <div class="modal-dialog" role="document">
                       <div class="modal-content">
                           <div class="modal-header">
                               <h5 class="modal-title" id="verifyModalContent_title">Add Category</h5>
                               <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                           </div>
                           <Form @submit="addCategory" :validation-schema="schema" class="user">
                               <div class="modal-body">
                                   
                                       <div class="form-group">
                                           <label class="col-form-label" for="category_name">Category Name:</label>
                                           <Field name="category_name" class="form-control" id="category_name" type="text" />
                                           <ErrorMessage name="category_name" class="text-danger p-3" />
                                       </div>
                               </div>
                               <div class="modal-footer">
                                   <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                   <button class="btn btn-primary" type="Submit">Submit</button>
                               </div>                            
                           </Form>
                       </div>
                   </div>
               </div>
    <!-- Edit Country Modal -->
 <div class="modal fade" id="editModalContent" tabindex="-1" role="dialog" aria-labelledby="editModalContent" aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content">
             <div class="modal-header">
                 <h5 class="modal-title" id="verifyModalContent_title">Edit Categoty</h5>
                 <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
             </div>
             <Form @submit="editCategory" :validation-schema="schema" class="user">
                 <div class="modal-body">
                     
                         <div class="form-group">
                             <label class="col-form-label" for="category_name">Category Name:</label>
                             <Field name="category_name" class="form-control" v-model="category_name" type="text" />
                             <ErrorMessage name="category_name" class="text-danger p-3" />
                         </div>
                 </div>
                 <div class="modal-footer">
                     <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                     <button class="btn btn-primary" type="Submit">Submit</button>
                 </div>                            
             </Form>
         </div>
     </div>
 </div>
   <div class="app-admin-wrap layout-horizontal-bar">
   <Sidebar />
     <Topbar />
     <div class="main-content-wrap d-flex flex-column">
       <div class="main-content">
           <Breadcrumbs />
               <div class="separator-breadcrumb border-top"></div>
               <div class="row mb-2">
                    <div class="col-md-12">
                      <button class="btn btn-light text-white ul-btn-raised--v2 m-1  float-end" type="button" data-bs-toggle="modal"
                    data-target="#verifyModalContent" data-whatever="@mdo">
                    <i class="nav-icon i-add text-primary text-white fw-bold"></i> ADD CATEGORY</button>
                      </div>
                  </div>
                 <div class="row mb-4">
                   <div class="col-md-12">
                           <div class="table-responsive">
                               <table class="table text-center" id="category_table">
                                   <thead>
                                       <tr class="bg-primary text-white">
                                           <th scope="col">#</th>
                                           <th scope="col">Category Name</th>
                                           <!-- <th scope="col">Avatar</th> -->
                                           <!-- <th scope="col">Email</th> -->
                                           <!-- <th scope="col">Status</th> -->
                                           <th scope="col">Action</th>
                                       </tr>
                               </thead>
                               <tbody>
                                   <tr v-for="category,index in categories" :key="category._id">
                                    <th scope="row">{{ index+1 }}</th>
                                   <td>{{ category.category_name }}</td>
                                   <!-- <td>
                                       <img
                                       class="rounded-circle m-0 avatar-sm-table"
                                       src="../../assets/images/faces/1.jpg"
                                       alt=""
                                       />
                                   </td> -->
                                   <!-- <td>Smith@gmail.com</td> -->
                                   <!-- <td>
                                       <span class="badge bg-success">Active</span>
                                   </td> -->
                                   <td>
                                       <a class="text-success me-2" @click="openEditCategory(category)"><i class="nav-icon i-Pen-2 fw-bold"></i></a>
                                       <a class="text-danger me-2 float-end" @click="deleteCategory(category._id)"><i class="nav-icon i-Close-Window fw-bold"></i></a>
                                   </td>
                                   </tr>
                               </tbody>
                               </table>
                           </div>
                       </div>
                   </div>
                </div>
         <div class="flex-grow-1"></div>
       <Footer />
     </div>
   </div>
 </template>
 
 <script>
 import Topbar from "@/components/partials/Topbar.vue";
 import Footer from "@/components/partials/Footer.vue";
 import Sidebar from "@/components/partials/Sidebar";
 import Breadcrumbs from "@/components/partials/Breadcrumbs";
 import "datatables.net-dt/js/dataTables.dataTables";
    import "@/assets/css/dataTables.bootstrap4.min.css";
    import "@/assets/css/buttons.dataTables.min.css";
    import "datatables.net-buttons/js/dataTables.buttons.js";
    import "datatables.net-buttons/js/buttons.colVis.js";
    import "datatables.net-buttons/js/buttons.flash.js";
    import "datatables.net-buttons/js/buttons.html5.js";
    import "datatables.net-buttons/js/buttons.print.js";
    import pdfMake from "pdfmake/build/pdfmake";
    import pdfFonts from "pdfmake/build/vfs_fonts";
    pdfMake.vfs = pdfFonts.pdfMake.vfs;

    import "@/assets/datatables/jquery.dataTables.min.js";
    import "@/assets/datatables/dataTables.bootstrap4.min.js";
    import "@/assets/datatables/dataTables.buttons.min.js";
    import "@/assets/datatables/buttons.html5.min.js";
    import "@/assets/datatables/buttons.print.min.js";
    import "@/assets/datatables/jszip.min.js";
 import { ALL_CATEGORIES_QUERY,ADD_CATEGORY_MUTATION, DELETE_CATEGORY_MUTATION,EDIT_CATEGORY_MUTATION } from '@/graphql';
 import { Form, Field, ErrorMessage } from "vee-validate"
  import * as yup from "yup"
 export default {
   name: "Category",
   components: { Sidebar, Topbar, Footer, Breadcrumbs, Form, Field, ErrorMessage },
   data () {
    const schema = yup.object().shape({
        category_name: yup
        .string()
        .required("Category name is required!"),
    });
    return {
    categories: [],
    category_name: '',
    category_id: '',
    schema
    }
   },
 apollo: {
   // fetch all categories
   categories: {
       query: ALL_CATEGORIES_QUERY
       }
     },
     methods: {
     addCategory(category) {
       this.$apollo
         .mutate({
           mutation: ADD_CATEGORY_MUTATION,
           variables: {
             categoryName: category.category_name,
           }
         })
         .then(response => {
           // redirect user
           $('#verifyModalContent').modal('hide')
             this.$swal({
                 title: 'Category added sucessfully',
                 position: 'top-end',
                 icon: 'success',
                 showConfirmButton: false,
                 timer: 2000
             });
             this.$apollo.queries.categories.refetch()
         }).catch((error) => {
             this.$swal({
                 title: error.message,
                 position: "top-end",
                 icon: "warning",
                 showConfirmButton: false,
                 timer: 3000,
             });
         })
       },
   deleteCategory(category_id) {
     this.$swal({
       title: "Do you want to Delete the category?",
       text: "You won't be able to revert this!",
       icon: "warning",
       showCancelButton: true,
       confirmButtonColor: "#3085d6",
       cancelButtonColor: "#d33",
       confirmButtonText: "Yes, delete it!",
     }).then((result) => {
       if (result.isConfirmed) {
           this.$apollo
               .mutate({
               mutation: DELETE_CATEGORY_MUTATION,
               variables: {
                   categoryId: category_id,
               }
               })
               .then(response => {
                   this.$swal({
                       title: 'Category deleted sucessfully',
                       position: 'top-end',
                       icon: 'success',
                       showConfirmButton: false,
                       timer: 2000
                   });
                   this.$apollo.queries.categories.refetch()
               }).catch((error) => {
                   this.$swal({
                       title: error.message,
                       position: "top-end",
                       icon: "warning",
                       showConfirmButton: false,
                       timer: 3000,
                   });
               })
       }
     });
   },
   openEditCategory(category) {
       this.category_name = category.category_name
       this.category_id = category._id
       $('#editModalContent').modal('show')

     },
   editCategory(category) {        
     this.$apollo
       .mutate({
         mutation: EDIT_CATEGORY_MUTATION,
         variables: {
           input: {
              id: this.category_id,
              category_name: category.category_name,
             }
         }
       })
       .then(response => {
         $('#editModalContent').modal('hide')
           this.$swal({
               title: 'Category updated sucessfully',
               position: 'top-end',
               icon: 'success',
               showConfirmButton: false,
               timer: 2000
           });
           this.$apollo.queries.categories.refetch()
       }).catch((error) => {
           this.$swal({
               title: error.message,
               position: "top-end",
               icon: "warning",
               showConfirmButton: false,
               timer: 3000,
           });
       })
     },
    async statusChange(){      
        this.categories = [];       
        $('#category_table').DataTable().destroy();
        await this.$apollo.query({
            query: ALL_CATEGORIES_QUERY
            }).then(response => {
                this.categories = response.data.categories
            })
        setTimeout(function () {
            $("#category_table").DataTable({
                destroy: true,
                pageLength: 5,
                lengthChange: true,
                processing: true,
                paging: true,
                info: false,
                dom: "Bfrtip",
                buttons: [
                { extend: 'csv', text: '<i class="fa-solid fa-file-pdf"></i>', className: 'btn btn-sm btn-outline-success mb-3 text-success' },
                { extend: 'pdf', text: '<i class="fa fa-file-pdf"></i>', className: 'btn btn-sm btn-outline-danger mb-3 text-danger' },
                { extend: 'print', text: '<i class="fa fa-print"></i>', className: 'btn btn-sm btn-outline-secondary mb-3 text-secondary' }
                ]  
            });
            }, 300);
    }
  
  },
    async created(){
      this.statusChange();
    }
}
  </script>
  
 