<template>
  <!-- Add Payment Modal -->
  <div class="modal fade" id="verifyModalContent" tabindex="-1" role="dialog" aria-labelledby="verifyModalContent" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                      <div class="modal-content">
                          <div class="modal-header">
                              <h5 class="modal-title" id="verifyModalContent_title">Add Payment</h5>
                              <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <Form @submit="addPayment" :validation-schema="schema" class="user">
                              <div class="modal-body">
                                  
                                      <div class="form-group">
                                          <label class="col-form-label" for="payment_name">Payment Name:</label>
                                          <Field name="payment_name" class="form-control" id="payment_name" type="text" />
                                          <ErrorMessage name="payment_name" class="text-danger p-3" />
                                      </div>
                              </div>
                              <div class="modal-footer">
                                  <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                  <button class="btn btn-primary" type="Submit">Submit</button>
                              </div>                            
                          </Form>
                      </div>
                  </div>
              </div>
        <!-- Edit Payment Modal -->
        <div class="modal fade" id="editModalContent" tabindex="-1" role="dialog" aria-labelledby="editModalContent" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalContent_title">Edit Payment</h5>
                                <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <Form @submit="editPayment" :validation-schema="schema"  class="user">
                                <div class="modal-body">
                                    
                                        <div class="form-group">
                                            <label class="col-form-label" for="payment_name">Payment Name:</label>
                                            <Field name="payment_name" class="form-control" v-model="payment_name" type="text" />
                                            <ErrorMessage name="payment_name" class="text-danger p-3" />
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                    <button class="btn btn-primary" type="Submit">Submit</button>
                                </div>                            
                            </Form>
                        </div>
                    </div>
                </div>
    <div class="app-admin-wrap layout-horizontal-bar">
    <Sidebar />
      <Topbar />
      <div class="main-content-wrap d-flex flex-column">
        <div class="main-content">
          <button class="btn btn-info text-white ul-btn-raised--v2 m-1  float-end"
                            type="button" data-bs-toggle="modal" data-target="#verifyModalContent" data-whatever="@mdo">
                            <i class="nav-icon i-add text-primary text-white fw-bold"></i> ADD PAYMENT</button>
            <Breadcrumbs />
                  <div class="separator-breadcrumb border-top"></div>
              
                  <section class="widget-card">
            <div class="row mb-4">
                <div class="col-lg-3 col-xl-3 mt-3" v-for="payment in payments" :key="payment._id">
                <div class="card" >
                  <!-- <div class="card"> -->
                  <img
                    class="d-block w-100 rounded rounded"
                    src="https://www.nopcommerce.com/images/thumbs/0019616_lipanampesa_550.png"
                    alt="First slide"
                  />
                  <div class="card-body">
                    <h5 class="card-title mb-2">{{ payment.payment_name }}</h5>
                    <button
                    class="btn btn-outline-info ul-btn-raised--v2 m-1"
                      type="button"
                      @click="openEditPayment(payment)">
                      Update
                    </button>
                    <button
                      
                    class="btn btn-outline-danger ul-btn-raised--v2 m-1 float-end"
                      type="button"
                      @click="deletePayment(payment._id)">
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            </div>
            </section>
              </div>
          <div class="flex-grow-1"></div>
        <Footer />
      </div>
    </div>
  </template>
  
  <script>
  import Topbar from "@/components/partials/Topbar.vue";
  import Footer from "@/components/partials/Footer.vue";
  import Sidebar from "@/components/partials/Sidebar";
  import Breadcrumbs from "@/components/partials/Breadcrumbs";
  import { ALL_PAYMENTS_QUERY, ADD_PAYMENT_MUTATION, DELETE_PAYMENT_MUTATION, EDIT_PAYMENT_MUTATION } from '@/graphql'
  // import { Form, Field, ErrorMessage } from "vee-validate"
  import * as yup from "yup"
  
  import { Form, Field, ErrorMessage } from "vee-validate"

  export default {
    name: "Option",
    components: { Sidebar, Topbar, Footer, Breadcrumbs, Form, Field, ErrorMessage },
    data () {
      const schema = yup.object().shape({
        payment_name: yup
          .string()
          .required("Payment name is required!"),
    });
    return {
      payments: [],
      payment_name: '',
      payment_id: '',
      schema
    }
  },
  apollo: {
    // fetch all payment options
    payments: {
        query: ALL_PAYMENTS_QUERY
        }
    },
    methods: {
    addPayment(payment) {
      this.$apollo
        .mutate({
          mutation: ADD_PAYMENT_MUTATION,
          variables: {
            paymentName: payment.payment_name,
          }
        })
        .then(response => {
          // redirect user
          $('#verifyModalContent').modal('hide')
            this.$swal({
                title: 'Payment added sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
            });
            this.$apollo.queries.payments.refetch()
        }).catch((error) => {
            this.$swal({
                title: error.message,
                position: "top-end",
                icon: "warning",
                showConfirmButton: false,
                timer: 3000,
            });
        })
      },
      openEditPayment(payment) {
        this.payment_name = payment.payment_name
        this.payment_id = payment._id
        $('#editModalContent').modal('show')

      },
    editPayment(payment) {    
      console.log(payment)    
      this.$apollo
        .mutate({
          mutation: EDIT_PAYMENT_MUTATION,
          variables: {
            input: {
               id: this.payment_id,
               payment_name: payment.payment_name,
              }
          }
        })
        .then(response => {
          $('#editModalContent').modal('hide')
            this.$swal({
                title: 'payment updated sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
            });
            this.$apollo.queries.payments.refetch()
        }).catch((error) => {
            this.$swal({
                title: error.message,
                position: "top-end",
                icon: "warning",
                showConfirmButton: false,
                timer: 3000,
            });
        })
      },
      deletePayment(payment_id) {
      this.$swal({
        title: "Delete the payment?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
      }).then((result) => {
        if (result.isConfirmed) {
            this.$apollo
                .mutate({
                mutation: DELETE_PAYMENT_MUTATION,
                variables: {
                    paymentId: payment_id,
                }
                })
                .then(response => {
                    this.$swal({
                        title: 'Payment deleted sucessfully',
                        position: 'top-end',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    this.$apollo.queries.payments.refetch()
                }).catch((error) => {
                    this.$swal({
                        title: error.message,
                        position: "top-end",
                        icon: "warning",
                        showConfirmButton: false,
                        timer: 3000,
                    });
                })
        }
      });
    },
  }
  }
  </script>