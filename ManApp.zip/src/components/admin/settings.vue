<template>
    <!-- Add Setting Modal -->
    <div class="modal fade" id="verifyModalContent" tabindex="-1" role="dialog" aria-labelledby="verifyModalContent" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="verifyModalContent_title">Add Setting</h5>
                                <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <Form @submit="addSetting" :validation-schema="schema" class="setting">
                                <div class="modal-body">
                                    
                                        
                                    <div class="form-group">
                                            <label class="col-form-label" for="controlPanelTitle">Control Panel Title:</label>
                                            <Field name="controlPanelTitle" class="form-control" id="controlPanelTitle" type="text" />
                                            <ErrorMessage name="controlPanelTitle" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="url">URL:</label>
                                            <Field name="url" class="form-control" id="url" type="text" />
                                            <ErrorMessage name="url" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="administratorEmail">Administrator Email:</label>
                                            <Field name="administratorEmail" class="form-control" id="administratorEmail" type="text" />
                                            <ErrorMessage name="administratorEmail" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="copyrightText">Copyright Text:</label>
                                            <Field name="copyrightText" class="form-control" id="copyrightText" type="text" />
                                            <ErrorMessage name="copyrightText" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="metaTagInfo">Meta Tag Info:</label>
                                            <Field name="metaTagInfo" class="form-control" id="metaTagInfo" type="text" />
                                            <ErrorMessage name="metaTagInfo" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="site">Site:</label>
                                            <Field name="site" class="form-control" id="site" type="text" />
                                            <ErrorMessage name="site" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="sitetitle">Site Title:</label>
                                            <Field name="sitetitle" class="form-control" id="sitetitle" type="text" />
                                            <ErrorMessage name="sitetitle" class="text-danger p-3" />
                                        </div>
                                        
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                    <button class="btn btn-primary" type="Submit">Submit</button>
                                </div>                            
                            </Form>
                        </div>
                    </div>
                </div>
     <!-- Edit Setting Modal -->
     <div class="modal fade" id="editModalContent" tabindex="-1" role="dialog" aria-labelledby="editModalContent" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalContent_title">Edit Setting</h5>
                                <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <Form @submit="editSetting" :validation-schema="schema" class="setting">
                                <div class="modal-body">
                                    
                                        <div class="form-group">
                                            <label class="col-form-label" for="controlPanelTitle">Control Panel Title:</label>
                                            <Field name="controlPanelTitle" class="form-control" v-model="controlPanelTitle" type="text" />
                                            <ErrorMessage name="controlPanelTitle" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="url">URL:</label>
                                            <Field name="url" class="form-control" v-model="url" type="text" />
                                            <ErrorMessage name="url" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="administratorEmail">Administrator Email:</label>
                                            <Field name="administratorEmail" class="form-control" v-model="administratorEmail" type="text" />
                                            <ErrorMessage name="administratorEmail" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="copyrightText">Copyright Text:</label>
                                            <Field name="copyrightText" class="form-control" v-model="copyrightText" type="text" />
                                            <ErrorMessage name="copyrightText" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="metaTagInfo">Meta Tag Info:</label>
                                            <Field name="metaTagInfo" class="form-control" v-model="metaTagInfo" type="text" />
                                            <ErrorMessage name="metaTagInfo" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="site">Site:</label>
                                            <Field name="site" class="form-control" v-model="site" type="text" />
                                            <ErrorMessage name="site" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="sitetitle">Site Title:</label>
                                            <Field name="sitetitle" class="form-control" v-model="sitetitle" type="text" />
                                            <ErrorMessage name="sitetitle" class="text-danger p-3" />
                                        </div>
                                        
                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                    <button class="btn btn-primary" type="Submit">Update</button>
                                </div>                            
                            </Form>
                        </div>
                    </div>
                </div>
    <div class="app-admin-wrap layout-horizontal-bar">
    <Sidebar />
      <Topbar />
      <div class="main-content-wrap d-flex flex-column">
        <div class="main-content">
            <Breadcrumbs />
                  <div class="separator-breadcrumb border-top"></div>
                  <div class="row mb-4">
                    <div class="col-md-12">
                      <button class="btn btn-info text-white ul-btn-raised--v2 m-1  float-end" type="button" data-bs-toggle="modal"
                    data-target="#verifyModalContent" data-whatever="@mdo">
                    <i class="nav-icon i-add text-primary text-white fw-bold"></i> ADD SYSTEM SETTINGS</button>
                      </div>
                  </div>
                  <div class="row mb-4">
                    <!-- table-->
                    <div class="col-lg-12 col-xl-12 mt-4">
                        <div class="card">
                            <div class="card-body">
                                <div class="ul-widget__head v-margin">
                                    <div class="ul-widget__head-label">
                                        <h3 class="ul-widget__head-title">System Settings</h3>
                                    </div>
                                    <button class="btn bg-white _r_btn border-0" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="_dot _inline-dot bg-primary"></span><span class="_dot _inline-dot bg-primary"></span><span class="_dot _inline-dot bg-primary"></span></button>
                                    <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 33px, 0px); top: 0px; left: 0px; will-change: transform;"><a class="dropdown-item" href="#">Action</a><a class="dropdown-item" href="#">Another action</a><a class="dropdown-item" href="#">Something else here</a>
                                        <div class="dropdown-divider"></div><a class="dropdown-item" href="#">Separated link</a>
                                    </div>
                                </div>
                                <div class="ul-widget-body">
                                    <div class="ul-widget3">
                                        <div class="ul-widget6__item--table">
                                            <table class="table" id="setting_table">
                                                <thead>
                                                    <tr class="ul-widget6__tr--sticky-th">
                                                        <th scope="col">Company</th>
                                                        <th scope="col">Site Title</th>
                                                        <th scope="col">Administrator Email</th>
                                                        <th scope="col">Panel Title</th>
                                                        <th scope="col">URL</th>
                                                        <th scope="col">Meta Tag</th>
                                                        <th scope="col">Actions</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <!-- start tr-->
                                                    <tr v-for="setting in systemSettings" :key="setting._id">
                                                        
                                                        <td>{{ setting.site }}</td>
                                                        <td>{{ setting.sitetitle }}</td>
                                                        <td>{{ setting.administratorEmail }}</td>
                                                        <td>{{ setting.controlPanelTitle }}</td>
                                                        <td>{{ setting.url }}</td>
                                                        <td>
                                                           {{ setting.metaTagInfo }}
                                                        </td>
                                                        <td>
                                                            <button class="btn bg-white _r_btn border-0" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="_dot _inline-dot bg-primary"></span><span class="_dot _inline-dot bg-primary"></span><span class="_dot _inline-dot bg-primary"></span></button>
                                                            <div class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 33px, 0px); top: 0px; left: 0px; will-change: transform;">
                                                                <!-- <a class="dropdown-item ul-widget__link--font" href="#"><i class="i-Bar-Chart-4"> </i> Export</a><a class="dropdown-item ul-widget__link--font" href="#"><i class="i-Data-Save"> </i> Save</a><a class="dropdown-item ul-widget__link--font" href="#"><i class="i-Duplicate-Layer"></i> Import</a> -->
                                                                <div class="dropdown-divider"></div>
                                                                <a class="dropdown-item ul-widget__link--font" href="#" @click="openEditSetting(setting)"><i class="i-Folder-Download"  ></i> Update</a>
                                                                <a class="dropdown-item ul-widget__link--font" href="#" @click="deleteSetting(setting._id)"><i class="i-Gears-2"></i> Delete</a>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <!-- end tr-->
                                                </tbody>
                                            </table>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              </div>
          <div class="flex-grow-1"></div>
        <Footer />
      </div>
    </div>
  </template>
  
  <script>
  import Topbar from "@/components/partials/Topbar.vue";
  import Footer from "@/components/partials/Footer.vue";
  import Sidebar from "@/components/partials/Sidebar";
  import "datatables.net-dt/js/dataTables.dataTables";
    import "@/assets/css/dataTables.bootstrap4.min.css";
    import "@/assets/css/buttons.dataTables.min.css";
    import "datatables.net-buttons/js/dataTables.buttons.js";
    import "datatables.net-buttons/js/buttons.colVis.js";
    import "datatables.net-buttons/js/buttons.flash.js";
    import "datatables.net-buttons/js/buttons.html5.js";
    import "datatables.net-buttons/js/buttons.print.js";
    import pdfMake from "pdfmake/build/pdfmake";
    import pdfFonts from "pdfmake/build/vfs_fonts";
    pdfMake.vfs = pdfFonts.pdfMake.vfs;

    import "@/assets/datatables/jquery.dataTables.min.js";
    import "@/assets/datatables/dataTables.bootstrap4.min.js";
    import "@/assets/datatables/dataTables.buttons.min.js";
    import "@/assets/datatables/buttons.html5.min.js";
    import "@/assets/datatables/buttons.print.min.js";
    import "@/assets/datatables/jszip.min.js";
  import Breadcrumbs from "@/components/partials/Breadcrumbs";import { ALL_SYTEMUSERS_MUTATION, ALL_SETTINGS_QUERY, ADD_SETTING_MUTATION, ALL_ROLES_MUTATION, ALL_COUNTRIES_QUERY, DELETE_SETTING_MUTATION, EDIT_SETTING_MUTATION } from '@/graphql';
  import * as yup from "yup"
  import { Form, Field, ErrorMessage } from "vee-validate"

  export default {
    name: "Setting",
    components: { Sidebar, Topbar, Footer, Breadcrumbs, Form, Field, ErrorMessage  },
    data () {
        const schema = yup.object().shape({
            controlPanelTitle: yup
        .string()
        .required("Panel Title is required!"),
        url: yup
        .string()
        .required("URL is required!"),
        copyrightText: yup
        .string()
        .required("copyrightText is required!"),
        administratorEmail: yup
        .string()
        .required("Email is required!"),
        metaTagInfo: yup
        .string()
        .required("Umeta Tag Info is required!"),
        site: yup
        .string()
        .required("site is required!"),
        sitetitle: yup
        .string()
        .required("Site Title is required!"),
    });
        return {
            allusers: [],
            allRoles: [],
            allcountries: [],
            systemSettings: [],
            controlPanelTitle: "",
            url: "",
            copyrightText: "",
            administratorEmail: "",
            metaTagInfo: "",
            site: "",
            sitetitle: "",
            setting_id: "",
            schema
        }
    },
  apollo: {
    systemSettings: {
        query: ALL_SETTINGS_QUERY
        },
    // fetch all users
    allRoles: {
        query: ALL_ROLES_MUTATION
        },
    allcountries: {
        query: ALL_COUNTRIES_QUERY
        }
    },
        methods: {
            addSetting(setting) {
                console.log(setting)
                this.$apollo
                    .mutate({
                    mutation: ADD_SETTING_MUTATION,
                    variables: { 
                            site: setting.site,
                            sitetitle: setting.sitetitle,
                            url: setting.url,
                            metaTagInfo: setting.metaTagInfo,
                            copyrightText: setting.copyrightText,
                            controlPanelTitle: setting.controlPanelTitle,
                            administratorEmail: setting.administratorEmail,
                    }
                    })
                    .then(response => {
                    // redirect setting
                    $('#verifyModalContent').modal('hide')
                        this.$swal({
                            title: 'System Setting added sucessfully',
                            position: 'top-end',
                            icon: 'success',
                            showConfirmButton: false,
                            timer: 2000
                        });
                        this.$apollo.queries.systemSettings.refetch()
                    }).catch((error) => {
                        this.$swal({
                            title: error.message,
                            position: "top-end",
                            icon: "warning",
                            showConfirmButton: false,
                            timer: 3000,
                        });
                    })
                },
                
    openEditSetting(setting) {
        this.setting_id = setting._id
        this.controlPanelTitle = setting.controlPanelTitle,
        this.url = setting.url,
        this.administratorEmail = setting.administratorEmail,
        this.copyrightText = setting.copyrightText,
        this.metaTagInfo = setting.metaTagInfo,
        this.site = setting.site,
        this.sitetitle = setting.sitetitle,
      $('#editModalContent').modal('show')

    },
    editSetting(setting) {
        console.log(setting)
      console.log(setting)
      this.$apollo
        .mutate({
          mutation: EDIT_SETTING_MUTATION,
          variables: {
            input: {
                id: this.setting_id,
                controlPanelTitle: setting.controlPanelTitle,
                url: setting.url,
                copyrightText: setting.copyrightText,
                administratorEmail: setting.administratorEmail,
                metaTagInfo: setting.metaTagInfo,
                site: setting.site,
                sitetitle: setting.sitetitle,
            }
          }
        })
        .then(response => {
          $('#editModalContent').modal('hide')
          this.$swal({
            title: 'setting updated sucessfully',
            position: 'top-end',
            icon: 'success',
            showConfirmButton: false,
            timer: 2000
          });
          this.$apollo.queries.systemSettings.refetch()
        }).catch((error) => {
          this.$swal({
            title: error.message,
            position: "top-end",
            icon: "warning",
            showConfirmButton: false,
            timer: 3000,
          });
        })
    },
    deleteSetting(setting_id) {
      this.$swal({
        title: "Delete the setting?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
      }).then((result) => {
        if (result.isConfirmed) {
          this.$apollo
            .mutate({
              mutation: DELETE_SETTING_MUTATION,
              variables: {
                settingId: setting_id,
              }
            })
            .then(response => {
              this.$swal({
                title: 'Setting deleted sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
              });
              this.$apollo.queries.systemSettings.refetch()
            }).catch((error) => {
              this.$swal({
                title: error.message,
                position: "top-end",
                icon: "warning",
                showConfirmButton: false,
                timer: 3000,
              });
            })
        }
      });
    },
    async statusChange(){      
        this.systemSettings = [];       
        $('#setting_table').DataTable().destroy();
        await this.$apollo.query({
            query: ALL_SETTINGS_QUERY
            }).then(response => {
                this.systemSettings = response.data.systemSettings
            })
        setTimeout(function () {
            $("#setting_table").DataTable({
                destroy: true,
                pageLength: 5,
                lengthChange: true,
                processing: true,
                paging: true,
                info: false,
                dom: "Bfrtip",
                buttons: [
                { extend: 'csv', text: '<i class="fa-solid fa-file-pdf"></i>', className: 'btn btn-sm btn-outline-success mb-3 text-success' },
                { extend: 'pdf', text: '<i class="fa fa-file-pdf"></i>', className: 'btn btn-sm btn-outline-danger mb-3 text-danger' },
                { extend: 'print', text: '<i class="fa fa-print"></i>', className: 'btn btn-sm btn-outline-secondary mb-3 text-secondary' }
                ]  
            });
            }, 300);
    }
  
  },
    async created(){
      this.statusChange();
    }
}
  </script>
  
 