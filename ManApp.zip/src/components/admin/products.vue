<template> 
<!-- Add Request Modal -->
    <div class="modal fade" id="verifyModalContent" tabindex="-1" role="dialog" aria-labelledby="verifyModalContent" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="verifyModalContent_title">Add Product</h5>
                                <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <Form @submit="addPaymentRequest" :validation-schema="schema" class="user">
                                <div class="modal-body">
                                    
                                        <div class="form-group">
                                        <!-- <div class="row"> -->
                                            <label class="col-form-label" for="productName">Product Name:</label>
                                            <Field name="productName" class="form-control" id="productName" type="text" placeholder="Product name" />
                                            <ErrorMessage name="productName" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                        <!-- <div class="row"> -->
                                            <label class="col-form-label" for="unitPrice">Unit Price:</label>
                                            <Field name="unitPrice" class="form-control" id="unitPrice" type="number" step="0.01" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="quantity">Quantity:</label>
                                            <Field name="quantity" class="form-control" id="quantity" type="text" placeholder="Quantity" />
                                            <ErrorMessage name="quantity" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                            <label for="categoryId" class="form-control-label">Category</label>
                                        <Field name="categoryId" class="form-control form-control-lg" v-model="categoryId" as="select">
                                            <option value="">-- Category--</option>
                                            <option v-for="category in categories" :value="category._id" :key="category._id">
                                            {{ category.category_name }}
                                            </option>
                                        </Field>
                                        <ErrorMessage name="categoryId" class="text-danger py-3 text-sm" />
                                        </div>
                                        <div class="form-group">
                                            <label for="supplierId" class="form-control-label">Supplier</label>
                                        <Field name="supplierId" class="form-control form-control-lg" v-model="supplierId" as="select">
                                            <option value="">-- Supplier--</option>
                                            <option v-for="supplier in suppliers" :value="supplier._id" :key="supplier._id">
                                            {{ supplier.supplier_name }}
                                            </option>
                                        </Field>
                                        <ErrorMessage name="supplierId" class="text-danger py-3 text-sm" />
                                        </div>


                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                    <button class="btn btn-primary" type="Submit">Submit</button>
                                </div>                            
                            </Form>
                        </div>
                    </div>
                </div>
     <!-- Edit Request Modal -->
     <div class="modal fade" id="editModalContent" tabindex="-1" role="dialog" aria-labelledby="editModalContent" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="editModalContent_title">Edit Product</h5>
                                <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <Form @submit="editPaymentRequest" :validation-schema="schema" class="user">
                                <div class="modal-body">
                                    
                                    <div class="form-group">
                                        <!-- <div class="row"> -->
                                            <label class="col-form-label" for="productName">Product Name:</label>
                                            <Field name="productName" class="form-control" v-model="productName" productNametype="text" />
                                            <ErrorMessage name="productName" class="text-danger p-3" />
                                        </div>
                                        <div class="form-group">
                                        <!-- <div class="row"> -->
                                            <label class="col-form-label" for="unitPrice">Unit Price:</label>
                                            <Field name="unitPrice" class="form-control" id="unitPrice" v-model="unitPrice" type="number" step="0.01" />
                                        </div>
                                        <div class="form-group">
                                            <label class="col-form-label" for="quantity">Quantity:</label>
                                            <Field name="quantity" class="form-control" v-model="quantity" type="text" />
                                            <ErrorMessage name="quantity" class="text-danger p-3" />
                                        </div>
                                        <!-- <div class="form-group">
                                            <label class="col-form-label" for="status">Status:</label>
                                            <Field name="status" class="form-control" id="status" type="text" />
                                            <ErrorMessage name="status" class="text-danger p-3" />
                                        </div> -->
                                        <div class="form-group">
                                            <label for="categoryId" class="form-control-label">Category</label>
                                        <Field name="categoryId" class="form-control form-control-lg" v-model="categoryId" as="select">
                                            <option value="">-- Category--</option>
                                            <option v-for="category in categories" :value="category._id" :key="category._id">
                                            {{ category.category_name }}
                                            </option>
                                        </Field>
                                        <ErrorMessage name="categoryId" class="text-danger py-3 text-sm" />
                                        </div>

                                </div>
                                <div class="modal-footer">
                                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                                    <button class="btn btn-primary" type="Submit">Submit</button>
                                </div>                            
                            </Form>
                        </div>
                    </div>
                </div>
    <div class="app-admin-wrap layout-horizontal-bar">
    <Sidebar />
      <Topbar />
      <div class="main-content-wrap d-flex flex-column">
        <div class="main-content">
            <button class="btn btn-info text-white ul-btn-raised--v2 m-1  float-end" type="button" data-bs-toggle="modal"
                    data-target="#verifyModalContent" data-whatever="@mdo">
                    <i class="nav-icon i-add text-primary text-white fw-bold"></i> ADD PRODUCT</button>
            <Breadcrumbs />
                  <div class="separator-breadcrumb border-top"></div>
                  <!-- content goes here-->
                <section class="product-cart">
                    <div class="row list-grid">
                        <div class="list-item col-lg-3 col-xl-3 mt-3"  v-for="product in products" :key="product._id">
                            <div class="card o-hidden mb-4 d-flex flex-column">
                                <div class="list-thumb d-flex"><img alt="" src="../../assets/images/products/speaker-1.jpg" /></div>
                                <div class="flex-grow-1 d-bock">
                                    <div class="card-body align-self-center d-flex flex-column justify-content-between align-items-lg-center"><a class="w-40 w-sm-100" href="">
                                            <div class="item-title">
                                                Product Name: {{ product.product_name }}
                                            </div>
                                        </a>
                                       
                                        <p class="m-0 text-muted text-small w-15 w-sm-100">Quantity  {{ product.quantity }}</p>
                                        <p class="m-0 text-muted text-small w-15 w-sm-100">Price: {{product.unitPrice}}
                                            <!-- <del class="text-secondary">$54.00</del> -->
                                        </p>
                                        <!-- <p class="m-0 text-muted text-small w-15 w-sm-100 d-none d-lg-block item-badges"><span class="badge bg-info">20% off</span></p> -->
                                        <div>
                                            <button class="btn btn-outline-gray-700 ul-btn-raised--v2 m-1" type="button"  @click="openEditPayment(product)">
                                                EDIT
                                            </button>
                                            <button class="btn btn-outline-danger ul-btn-raised--v2 m-1  float-end" type="button" @click="deletePayment(product._id)">
                                                DELETE
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
              </div>
          <div class="flex-grow-1"></div>
        <Footer />
      </div>
    </div>
  </template>
  
  <script>
  import Topbar from "@/components/partials/Topbar.vue";
  import Footer from "@/components/partials/Footer.vue";
  import Sidebar from "@/components/partials/Sidebar";
  import Breadcrumbs from "@/components/partials/Breadcrumbs";
  import { EDIT_PRODUCT_MUTATION,DELETE_PRODUCT_MUTATION,ADD_PRODUCT_MUTATION, ALL_SUPPLIERS_QUERY,   ALL_DONORS_QUERY, ALL_CATEGORIES_QUERY, ALL_PRODUCTS_QUERY  } from '@/graphql';
  import { Form, Field, ErrorMessage } from "vee-validate"
  import * as yup from "yup"
  export default {
    name: "Product",
    components: { Sidebar, Topbar, Footer, Breadcrumbs, Form, Field, ErrorMessage },
    data () {
      const schema = yup.object().shape({
        quantity: yup
          .string()
          .required("Quantity is required!"),
          productName: yup
          .string()
          .required("product name is required!"),
          categoryId: yup
          .string()
          .required("category is required!"),
    });
        return {
            products: [],
          filterUsers: [],
          categories: [],
          suppliers: [],
          quantity: '',
          productName: '',
          categoryId: '',
          payment_id: '',
          supplierId: '',
          unitPrice: '',
          schema
        }
    },
  apollo: {
    // fetch all payments,
    products: {
        query: ALL_PRODUCTS_QUERY
        },
    categories: {
        query: ALL_CATEGORIES_QUERY
        },
    suppliers: {
      query: ALL_SUPPLIERS_QUERY
    }
      },
      methods: {
      addPaymentRequest(payment) {
        this.$apollo
          .mutate({
            mutation: ADD_PRODUCT_MUTATION,
            variables: {
                productName: payment.productName,
                quantity: payment.quantity,
                categoryId: payment.categoryId,  
                supplierId: payment.supplierId, 
                unitPrice: parseFloat(payment.unitPrice),
                }
          })
          .then(response => {
            // redirect user
            $('#verifyModalContent').modal('hide')
              this.$swal({
                  title: 'Payment added sucessfully',
                  position: 'top-end',
                  icon: 'success',
                  showConfirmButton: false,
                  timer: 2000
              });
              this.$apollo.queries.products.refetch()
          }).catch((error) => {
              this.$swal({
                  title: error.message,
                  position: "top-end",
                  icon: "warning",
                  showConfirmButton: false,
                  timer: 3000,
              });
          })
        },
    deletePayment(payment_id) {
      this.$swal({
        title: "Do you want to Delete the payment?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
      }).then((result) => {
        if (result.isConfirmed) {
            this.$apollo
                .mutate({
                mutation: DELETE_PRODUCT_MUTATION,
                variables: {
                    productId: payment_id,
                }
                })
                .then(response => {
                    this.$swal({
                        title: 'Payment deleted sucessfully',
                        position: 'top-end',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    this.$apollo.queries.products.refetch()
                }).catch((error) => {
                    this.$swal({
                        title: error.message,
                        position: "top-end",
                        icon: "warning",
                        showConfirmButton: false,
                        timer: 3000,
                    });
                })
        }
      });
    },
    openEditPayment(payment) {
        this.payment_id = payment._id
        this.productName = payment.product_name
        this.categoryId = payment.category._id
        this.quantity = payment.quantity
        this.unitPrice = payment.unitPrice
        $('#editModalContent').modal('show')

      },
    editPaymentRequest(payment) {        
      this.$apollo
        .mutate({
          mutation: EDIT_PRODUCT_MUTATION,
          variables: {
            input: {
                id: this.payment_id,
                quantity: payment.quantity,
                product_name: payment.productName,
                unitPrice: parseFloat(payment.unitPrice),
                category: payment.categoryId,
              }
          }
        })
        .then(response => {
          $('#editModalContent').modal('hide')
            this.$swal({
                title: 'Payment updated sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
            });
            this.$apollo.queries.products.refetch()
        }).catch((error) => {
            this.$swal({
                title: error.message,
                position: "top-end",
                icon: "warning",
                showConfirmButton: false,
                timer: 3000,
            });
        })
      }
    }
  
  }
  </script>
 