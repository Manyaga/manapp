<template>
  <!-- Add FAQ Modal -->
  <div class="modal fade" id="verifyModalContent" tabindex="-1" role="dialog" aria-labelledby="verifyModalContent"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="verifyModalContent_title">Add FAQ</h5>
          <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <Form @submit="addFAQ" :validation-schema="schema" class="user">
          <div class="modal-body">

            <div class="form-group">
              <label class="col-form-label" for="question">Question:</label>
              <Field name="question" class="form-control" id="question" type="text" placeholder="question" />
              <ErrorMessage name="question" class="text-danger p-3" />
            </div>
            <div class="form-group">
              <label class="col-form-label" for="answer">Answer:</label>
              <Field name="answer" class="form-control" id="answer" type="text" placeholder="answer" />
              <ErrorMessage name="answer" class="text-danger p-3" />
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
            <button class="btn btn-primary" type="Submit">Submit</button>
          </div>
        </Form>
      </div>
    </div>
  </div>
  <!-- Edit FAQ Modal -->
  <div class="modal fade" id="editModalContent" tabindex="-1" role="dialog" aria-labelledby="editModalContent"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editModalContent_title">Edit FAQ</h5>
          <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        
        <Form @submit="editFAQ" :validation-schema="schema" class="user">
          <div class="modal-body">

            <div class="form-group">
              <label class="col-form-label" for="question">Question:</label>
              <Field name="question" class="form-control" v-model="question" type="text" />
              <ErrorMessage name="question" class="text-danger p-3" />
            </div>
            <div class="form-group">
              <label class="col-form-label" for="answer">Answer:</label>
              <Field name="answer" class="form-control" v-model="answer" type="text" />
              <ErrorMessage name="answer" class="text-danger p-3" />
            </div>
            <!-- <div class="form-group">
              <label class="col-form-label" for="status">Status:</label>
              <Field name="status" class="form-control" v-model="status" type="text" />
              <ErrorMessage name="status" class="text-danger p-3" />
            </div> -->
          </div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
            <button class="btn btn-primary" type="Submit">Update</button>
          </div>
        </Form>
      </div>
    </div>
  </div>
    <div class="app-admin-wrap layout-horizontal-bar">
    <Sidebar />
      <Topbar />
      <div class="main-content-wrap d-flex flex-column">
        <div class="main-content">
          <button class="btn btn-info text-white ul-btn-raised--v2 m-1  float-end"
                      type="button" data-bs-toggle="modal" data-target="#verifyModalContent" data-whatever="@mdo">
                      <i class="nav-icon i-add text-primary text-white fw-bold"></i> ADD FAQ</button>
            <Breadcrumbs />
                  <div class="separator-breadcrumb border-top"></div>                  
                  <div class="row mb-4"  >
                    <div class="col-lg-12 col-xl-12 mt-3 mb-3">
                        <div class="card card-body ul-border__bottom" v-for="faq in faqs" :key="faq._id">
                                <div class="text-center">
                                    <span><h5 class="heading text-primary">{{ faq.question }}</h5> <button class="btn btn-outline-gray-700 ul-btn-raised--v2 m-1"
                                        type="button"  @click="openEditFAQ(faq)">EDIT</button>
                                      <button class="btn btn-outline-danger ul-btn-raised--v2 m-1 "
                                        type="button"  @click="deleteFAQ(faq._id)">DELETE</button></span>
                                    <!-- <div class="ul-widget-card--line mt-2">                        
                                      <button class="btn btn-outline-primary ul-btn-raised--v2 m-1"
                                        type="button"  @click="openEditFAQ(faq)">EDIT</button>
                                      <button class="btn btn-outline-danger ul-btn-raised--v2 m-1  float-end"
                                        type="button"  @click="deleteFAQ(faq._id)">DELETE</button>
                                    </div> -->
                                    <p class="mb-3 text-muted">Click to See the Answer</p><a class="text-default collapsed" href="#collapse-icon" data-bs-toggle="collapse" aria-expanded="false"><i class="i-Arrow-Down-2 t-font-boldest"></i></a>
                                </div>
                                <div class="collapse" id="collapse-icon">
                                    <div class="mt-3">
                                        {{ faq.answer }}

                                    </div>
                                </div>
                            </div>
                        </div>
                </div>
              </div>
          <div class="flex-grow-1"></div>
        <Footer />
      </div>
    </div>
  </template>
  
  <script>
  import Topbar from "@/components/partials/Topbar.vue";
  import Footer from "@/components/partials/Footer.vue";
  import Sidebar from "@/components/partials/Sidebar";
  import Breadcrumbs from "@/components/partials/Breadcrumbs";
  import { DELETE_FAQ_MUTATION, EDIT_FAQ_MUTATION, ADD_FAQ_MUTATION, ALL_FAQS_QUERY } from '@/graphql';
  
  import * as yup from "yup"
  import { Form, Field, ErrorMessage } from "vee-validate"

  export default {
    name: "Faqs",
    components: { Sidebar, Topbar, Footer, Breadcrumbs, Form, Field, ErrorMessage },

  data () {
    const schema = yup.object().shape({
      answer: yup
        .string()
        .required("Answer is required!"),
        question: yup
        .string()
        .required("Question is required!"),
    });
      return {
        faqs: [],
          question: "",
          answer: "",
          faq_id: "",
          status: "",
          schema
      }
  },
apollo: {
  faqs: {
      query: ALL_FAQS_QUERY
      },
  },
      methods: {
          addFAQ(faq) {
              console.log(faq)
              this.$apollo
                  .mutate({
                  mutation: ADD_FAQ_MUTATION,
                  variables: {
                    question: faq.question,
                    answer: faq.answer
                  }
                  })
                  .then(response => {
                  // redirect user
                  $('#verifyModalContent').modal('hide')
                      this.$swal({
                          title: 'FAQ added sucessfully',
                          position: 'top-end',
                          icon: 'success',
                          showConfirmButton: false,
                          timer: 2000
                      });
                      this.$apollo.queries.faqs.refetch()
                  }).catch((error) => {
                      this.$swal({
                          title: error.message,
                          position: "top-end",
                          icon: "warning",
                          showConfirmButton: false,
                          timer: 3000,
                      });
                  })
              },
              
  openEditFAQ(faq) {
      this.faq_id = faq._id
      this.answer = faq.answer,
      this.question = faq.question,
    $('#editModalContent').modal('show')

  },
  editFAQ(faq) {
      console.log(faq)
    console.log(faq)
    this.$apollo
      .mutate({
        mutation: EDIT_FAQ_MUTATION,
        variables: {
          input: {
              id: this.faq_id,
              answer: faq.answer,
              question: faq.question,
              status: faq.status,
          }
        }
      })
      .then(response => {
        $('#editModalContent').modal('hide')
        this.$swal({
          title: 'FAQ updated sucessfully',
          position: 'top-end',
          icon: 'success',
          showConfirmButton: false,
          timer: 2000
        });
        this.$apollo.queries.faqs.refetch()
      }).catch((error) => {
        this.$swal({
          title: error.message,
          position: "top-end",
          icon: "warning",
          showConfirmButton: false,
          timer: 3000,
        });
      })
  },
  deleteFAQ(faq_id) {
    this.$swal({
      title: "FAQ?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        this.$apollo
          .mutate({
            mutation: DELETE_FAQ_MUTATION,
            variables: {
              faqId: faq_id,
            }
          })
          .then(response => {
            this.$swal({
              title: 'FAQ deleted sucessfully',
              position: 'top-end',
              icon: 'success',
              showConfirmButton: false,
              timer: 2000
            });
            this.$apollo.queries.faqs.refetch()
          }).catch((error) => {
            this.$swal({
              title: error.message,
              position: "top-end",
              icon: "warning",
              showConfirmButton: false,
              timer: 3000,
            });
          })
      }
    });
  }
          }
    }
</script>