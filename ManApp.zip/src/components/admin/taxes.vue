<template>
<!-- Add Country tax Modal -->
<div class="modal fade" id="verifyModalContent" tabindex="-1" role="dialog" aria-labelledby="verifyModalContent" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="verifyModalContent_title">ADD TAX</h5>
                <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <Form @submit="addCountry" :validation-schema="schema" class="user">
                <div class="modal-body">                    
                    <div class="form-group">
                        <label class="col-form-label" for="tax">Tax %:</label>
                        <Field name="tax" class="form-control" type="text" />
                        <ErrorMessage name="tax" class="text-danger p-3" />
                    </div>
                    <div class="form-group">
                        <label class="col-form-label" for="tax">Country:</label>
                        <Field name="country_id" class="form-control" v-model="country_id" as="select">
                        <option value="" :selected="selected">--Select Country--</option>
                        <option v-for="country in allcountries" :value="country._id" :key="country._id">
                          {{country.country_name }}
                        </option>
                        </Field>
                        <ErrorMessage name="country_id" class="text-danger py-3 text-sm" />
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-primary" type="Submit">Submit</button>
                </div>                            
            </Form>
        </div>
    </div>
</div>
<!-- Edit Country tax Modal -->
<div class="modal fade" id="editModalContent" tabindex="-1" role="dialog" aria-labelledby="editModalContent" aria-hidden="true">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="verifyModalContent_title">EDIT TAX</h5>
              <button class="btn btn-close" type="button" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <Form @submit="editCountry" :validation-schema="schema" class="user">
              <div class="modal-body">                  
                  <div class="form-group">
                      <label class="col-form-label" for="tax">Country tax Name:</label>
                      <Field name="tax" class="form-control" v-model="tax" type="text" />
                      <ErrorMessage name="tax" class="text-danger p-3" />
                  </div>
                  <div class="form-group">
                    <label class="col-form-label" for="tax">Country:</label>
                    <Field name="country_id" class="form-control" v-model="country_id" as="select">
                    <option value="" :selected="selected">--Select Country--</option>
                    <option v-for="country in allcountries" :value="country._id" :key="country._id">
                      {{country.country_name }}
                    </option>
                    </Field>
                    <ErrorMessage name="country_id" class="text-danger py-3 text-sm" />
                </div>
              </div>
              <div class="modal-footer">
                  <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Close</button>
                  <button class="btn btn-primary" type="Submit">Submit</button>
              </div>                            
          </Form>
      </div>
  </div>
  </div>
    <div class="app-admin-wrap layout-horizontal-bar">
    <Sidebar />
      <Topbar />
      <div class="main-content-wrap d-flex flex-column">
        <div class="main-content"> 
          <button class="btn btn-info text-white ul-btn-raised--v2 m-1 text-white float-end" type="button" data-bs-toggle="modal" data-target="#verifyModalContent" data-whatever="@mdo">
                          <i class="nav-icon i-add text-white fw-bold"></i> ADD TAX 
                        </button>
            <Breadcrumbs />
                  <div class="separator-breadcrumb border-top"></div>
                  <div class="row mb-4">
                    <div class="col-lg-12 col-xl-12">
                  <div class="card text-center border-primary">
                    <div class="card-header bg-primary border-0">
                        <h4 class="float-start card-title mr-0 text-white mb-0">TAX % PER COUNTRY</h4>
                    </div>
                    <div class="card-body">
                      <div class="ul-widget5">
                        <div class="ul-widget-s5__item mb-5" v-for="(tax, index) in taxes" v-bind:key="tax._id">
                          <div class="ul-widget-s5__content">
                            <div class="ul-widget-s5__pic">
                              <img
                                id="userDropdown"
                                src="https://cdn.britannica.com/15/15-004-B5D6BF80/Flag-Kenya.jpg"
                                alt=""
                                data-bs-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false"
                              />
                            </div>
                            <div class="ul-widget-s5__section">
                              <a class="ul-widget4__title" href="#"
                                >{{ tax.country.country_name }}</a
                              >
                            </div>
                          </div>
                          <div class="ul-widget-s5__content">
                            <div class="ul-widget-s5__progress">
                              <div class="progress">
                                <div
                                  class="progress-bar bg-success progress-bar-striped progress-bar-animated"
                                  role="progressbar"
                                  aria-valuemin="0"
                                  aria-valuemax="100"
                                  :aria-valuenow="tax.tax"
                                  style="width: 25%"
                                >
                                  {{ tax.tax }}%
                                </div>
                              </div>
                            </div>
                            <button
                              class="btn btn-outline-info m-1"
                              type="button" @click="openEditTax(tax)"
                            >
                              Update
                            </button>
                            <button
                              class="btn btn-outline-danger"
                              type="button" @click="deleteTax(tax._id)"
                            >
                              Delete
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- -->
                    <!-- -->
                  </div>
                </div>
                </div>
              </div>
          <div class="flex-grow-1"></div>
        <Footer />
      </div>
    </div>
  </template>
  
  <script>
  import Topbar from "@/components/partials/Topbar.vue";
  import Footer from "@/components/partials/Footer.vue";
  import Sidebar from "@/components/partials/Sidebar";
  import Breadcrumbs from "@/components/partials/Breadcrumbs";
  import { Form, Field, ErrorMessage } from "vee-validate"
  import * as yup from "yup"
  import { ALL_TAX_QUERY, ALL_COUNTRIES_QUERY, ADD_TAX_MUTATION, EDIT_TAX_MUTATION, DELETE_TAX_MUTATION } from '@/graphql'
  export default {
    name: "Tax",
    components: { Sidebar, Topbar, Footer, Breadcrumbs, Form, Field, ErrorMessage },
    data () {
    const schema = yup.object().shape({
        tax: yup
          .string()
          .required("Country tax name is required!"),
        country_id: yup
        .string("Country is required!")
        .required("Country is required!"),
    });
    return {
      taxes: [],
      allcountries: [],
      tax: '',
      country_id: '',
      tax_id: "",
      schema
    }
  },
  apollo: {
    // fetch all countries
    taxes: {
        query: ALL_TAX_QUERY
        },
    allcountries: {
      query: ALL_COUNTRIES_QUERY
    }
    },
    methods: {
    addCountry(tax) {
      this.$apollo
        .mutate({
          mutation: ADD_TAX_MUTATION,
          variables: {
            tax: tax.tax,
            countryId: tax.country_id,
          }
        })
        .then(response => {
          $('#verifyModalContent').modal('hide')
            this.$swal({
                title: 'Country tax added sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
            });
            this.$apollo.queries.taxes.refetch()
        }).catch((error) => {
            this.$swal({
                title: error.message,
                position: "top-end",
                icon: "warning",
                showConfirmButton: false,
                timer: 3000,
            });
        })
      },
      openEditTax(tax) {
        this.tax = tax.tax
        this.country_id = tax.country._id
        this.tax_id = tax._id
        $('#editModalContent').modal('show')

      },
      editCountry(tax) {
      this.$apollo
        .mutate({
          mutation: EDIT_TAX_MUTATION,
          variables: {
            input: {
                id: this.tax_id,
                tax: tax.tax,
                country: tax.country_id,
              }
          }
        })
        .then(response => {
          $('#editModalContent').modal('hide')
            this.$swal({
                title: 'Country tax updated sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
            });
            this.$apollo.queries.taxes.refetch()
        }).catch((error) => {
            this.$swal({
                title: error.message,
                position: "top-end",
                icon: "warning",
                showConfirmButton: false,
                timer: 3000,
            });
        })
      },
      deleteTax(tax_id) {
      this.$swal({
        title: "Delete the Country Tax?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!",
      }).then((result) => {
        if (result.isConfirmed) {
            this.$apollo
                .mutate({
                mutation: DELETE_TAX_MUTATION,
                variables: {
                    taxId: tax_id,
                }
                })
                .then(response => {
                    this.$swal({
                        title: 'Country tax deleated sucessfully',
                        position: 'top-end',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    this.$apollo.queries.taxes.refetch()
                }).catch((error) => {
                    this.$swal({
                        title: error.message,
                        position: "top-end",
                        icon: "warning",
                        showConfirmButton: false,
                        timer: 3000,
                    });
                })
        }
      });
    },
  
  }
}
  </script>