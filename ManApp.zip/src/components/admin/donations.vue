<template>
    <div class="app-admin-wrap layout-horizontal-bar">
    <Sidebar />
      <Topbar />
      <div class="main-content-wrap d-flex flex-column">
        <div class="main-content">
            <Breadcrumbs />
                  <div class="separator-breadcrumb border-top"></div>
                  <section>
          <h4 class="mb-3">Request donations</h4>
          <div class="row">
            <div class="col-lg-6 mb-3" v-for="(donation, index ) in requestDonated" :key="donation._id">
              <div class="card card-body ul-border__bottom">
                <div class="text-center">
                  <h5 class="heading text-primary">REQUEST CODE: {{ donation.request_code }}</h5>
                  <p class="mb-3 text-muted"><b>PRODUCT:</b> {{ donation.product.product_name.toUpperCase() }}</p>
                  <h6 class="mb-3 text-muted"><b>TOTAL AMOUNT:</b> {{ donation.amount }}</h6>
                  <h6 class="mb-3 text-muted"><b>DONATED AMOUNT:</b> {{ donation.donatedAmount }}</h6>
                  <a class="text-default collapsed" href="#collapse-icon" data-bs-toggle="collapse"
                    aria-expanded="false"><i class="i-Arrow-Down-2 t-font-boldest"></i></a>
                </div>
                <div class="collapse" id="collapse-icon">
                  <div class="mt-3">
                    <div class="row">
                      <div class="col-md-12 table-responsive">
                        <table class="table table-hover mb-4" id="donationss_table" >
                          <thead class="bg-gray-300">
                            <tr>
                              <th scope="col">#</th>
                              <!-- <th scope="col">Donor Image</th> -->
                              <th scope="col">Donor</th>
                              <th scope="col">Donation Code</th>
                              <th scope="col">Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="(donor, index) in requestDonated[index].donations" :key="donor._id">
                              <th scope="row">{{ index + 1 }}</th>
                              <!-- <td><img class="rounded-circle m-0 avatar-sm-table" v-bind:src="donor.donar.profilePhoto"
                                  alt="" /></td> -->
                              <td>{{ donor.donar.first_name.toUpperCase() + " " + donor.donar.last_name.toUpperCase() }}
                              </td>
                              <td>{{donor.donation_code}}</td>
                              <td>$ {{ donor.amount }}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
              </div>
          <div class="flex-grow-1"></div>
        <Footer />
      </div>
    </div>
  </template>
  
  <script>
  import Topbar from "@/components/partials/Topbar.vue";
  import Footer from "@/components/partials/Footer.vue";
  import Sidebar from "@/components/partials/Sidebar";
  import Breadcrumbs from "@/components/partials/Breadcrumbs";
  import "datatables.net-dt/js/dataTables.dataTables";
    import "@/assets/css/dataTables.bootstrap4.min.css";
    import "@/assets/css/buttons.dataTables.min.css";
    import "datatables.net-buttons/js/dataTables.buttons.js";
    import "datatables.net-buttons/js/buttons.colVis.js";
    import "datatables.net-buttons/js/buttons.flash.js";
    import "datatables.net-buttons/js/buttons.html5.js";
    import "datatables.net-buttons/js/buttons.print.js";
    import pdfMake from "pdfmake/build/pdfmake";
    import pdfFonts from "pdfmake/build/vfs_fonts";
    pdfMake.vfs = pdfFonts.pdfMake.vfs;

    import "@/assets/datatables/jquery.dataTables.min.js";
    import "@/assets/datatables/dataTables.bootstrap4.min.js";
    import "@/assets/datatables/dataTables.buttons.min.js";
    import "@/assets/datatables/buttons.html5.min.js";
    import "@/assets/datatables/buttons.print.min.js";
    import "@/assets/datatables/jszip.min.js";
    import moment from 'moment'
  import { DONATIONREQUESTS_WITH_DONATION_QUERY, ALL_DONATIONREQUESTS_QUERY} from '@/graphql';

  export default {
    name: "Donation",
    components: { Sidebar, Topbar, Footer, Breadcrumbs},
    data () {
        return {
          donations: [],
          amount: '',
          requestDonated: [],
        }
    },
      methods: {
        formatDate(created) {
      let formartedDate =  moment(created).format('YYYY-MM-DD HH:mm')
      console.log(created)
      return moment(formartedDate, "YYYY-MM-DD HH:mm").fromNow();
    }, 
  async statusChange(){      
        this.requestDonated = [];       
        $('#donationss_table').DataTable().destroy();
          await this.$apollo.query({
          query: DONATIONREQUESTS_WITH_DONATION_QUERY,
          fetchPolicy: 'network-only'
          }).then(response => {
              this.requestDonated = response.data.donationRequestsWithDonations
              
          })
        setTimeout(function () {
            $("#donationss_table").DataTable({
                destroy: true,
                pageLength: 5,
                lengthChange: true,
                processing: true,
                paging: true,
                info: false,
                dom: "Bfrtip",
                buttons: [
                { extend: 'csv', text: '<i class="fa-solid fa-file-pdf"></i>', className: 'btn btn-sm btn-outline-success mb-3 text-success' },
                { extend: 'pdf', text: '<i class="fa fa-file-pdf"></i>', className: 'btn btn-sm btn-outline-danger mb-3 text-danger' },
                { extend: 'print', text: '<i class="fa fa-print"></i>', className: 'btn btn-sm btn-outline-secondary mb-3 text-secondary' }
                ]  
            });
            }, 300);
    }
  },
  async created() {
      this.statusChange();
  }
}
  </script>
  
 