<template>
    <div class="app-admin-wrap layout-horizontal-bar">
        <Sidebar />
        <Topbar />
        <div class="main-content-wrap d-flex flex-column">
            <div class="main-content">
                <Breadcrumbs />
                <div class="separator-breadcrumb border-top"></div>
                <div class="row mb-4">
                    <div class="col-md-12">
                        <div class="card o-hidden mb-4">
                            <div class="card-body">
                                <div class="ul-widget__head">
                                    <div class="ul-widget__head-label">
                                        <h3 class="ul-widget__head-title">Fundraise Request</h3>
                                    </div>
                                    <div class="ul-widget__head-toolbar">
                                        <ul class="nav nav-tabs profile-nav"
                                            role="tablist">
                                            <li class="nav-item">
                                                <a class="nav-link active show" data-bs-toggle="tab" role="tab"
                                                    aria-selected="true" @click="statusChange('1')">Open</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-bs-toggle="tab" role="tab" aria-selected="false"
                                                    @click="statusChange('2')">In Progress</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-bs-toggle="tab" role="tab" aria-selected="false"
                                                    @click="statusChange('3')">Closed</a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" data-bs-toggle="tab" role="tab" aria-selected="false"
                                                    @click="statusChange('4')">Rejected</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div v-if="fundraisersPerStatus.length > 0" class="row mb-4">
                                    <div class="col-lg-4 col-xl-4 mt-3" v-for="requestdon in fundraisersPerStatus"
                                        :key="requestdon._id">
                                        <div class="card">
                                            <div class="card-body"><img class="d-block w-100 rounded"
                                                    v-bind:src="requestdon.member.profilePhoto" alt="First slide" />
                                                <div class="ul-widget-card__progress-rate"><span>$ {{
                                                    requestdon.donatedAmount }}</span><span>$ {{requestdon.amount }}</span></div>
                                                <div class="progress progress--height mb-3">
                                                    <div :class="donationPercentage(requestdon.donatedAmount, requestdon.amount) < '50' ? 'progress-bar progress-bar-striped bg-danger' : (donationPercentage(requestdon.donatedAmount, requestdon.amount) > '90' ? 'progress-bar progress-bar-striped bg-success' : 'progress-bar progress-bar-striped bg-Primary')"
                                                        role="progressbar"
                                                        :style="{ 'width': donationPercentage(requestdon.donatedAmount, requestdon.amount) + '%' }"
                                                        aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <h5 class="card-title mt-4 mb-2">{{
                                                    requestdon.member.first_name.toUpperCase()
                                                    + " " + requestdon.member.last_name.toUpperCase() }}</h5>
                                                <p class="card-text text-mute">{{ requestdon.story }}</p>
                                                <div class="ul-widget-card__full-status mb-3">
                                                    <button v-if="requestdon.status == '1'"
                                                        class="btn btn-outline-success ul-btn-raised--v2 m-1"
                                                        type="button" @click="updateStatus('2', requestdon._id)">APROVE</button>
                                                    <button v-if="requestdon.status == '1'"
                                                        class="btn btn-outline-danger ul-btn-raised--v2 m-1 float-end"
                                                        type="button" @click="updateStatus('4', requestdon._id)">REJECT</button>
                                                    <button v-if="requestdon.status == '2' || requestdon.status == '3'"
                                                        class="btn btn-outline-secondary ul-btn-raised--v2 m-1 float-end"
                                                        type="button" @click="preview(requestdon)">PREVIEW</button>
                                                </div>
                                                <div class="separator-breadcrumb border-top"></div>
                                                <div class="ul-widget-card__rate-icon">
                                                    <span>
                                                        <p class="text-small font-italic"><i
                                                                class="i-Map-Marker text-warning"></i>{{
                                                                    requestdon.member.country.country_name.toUpperCase() }}</p>
                                                    </span>
                                                    <span>
                                                        <p class="text-small font-italic"><i
                                                                class="i-Telephone text-primary"></i>
                                                            {{ requestdon.member.phone_number }}</p>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div v-if="fundraisersPerStatus.length == 0" class="row">
                                    <div class="user-profile mb-4">
                                        <div class="ul-widget-card__user-info">
                                            <img class="profile-picture avatar-lg mb-2 mt-2"
                                                src="https://cdn.pixabay.com/photo/2014/12/21/23/57/money-576443_1280.png"
                                                alt="" />

                                        </div>
                                        <div class="ul-widget-card--line text-center mt-2">
                                            <a type="button" data-bs-toggle="modal" data-target="#verifyModalContent"
                                                data-whatever="@mdo"> No fundraiser yet please check later!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex-grow-1"></div>
            <Footer />
        </div>
    </div>
</template>

<script>
import TokenService from "@/services/token.service";
import Topbar from "@/components/partials/Topbar.vue";
import Footer from "@/components/partials/Footer.vue";
import Sidebar from "@/components/partials/Sidebar";
import Breadcrumbs from "@/components/partials/Breadcrumbs";

import { FUNDRAISER_BY_STATUS_QUERY, EDIT_FUNDRAISER_MUTATION } from '@/graphql';
export default {
    name: "Request",
    components: { Sidebar, Topbar, Footer, Breadcrumbs },
    data() {
        return {
            fundraisersPerStatus: [],
            amount: '',
            story: '',
            status: '1'
        }
    },
    methods: {
        async statusChange(status){
            this.status = status;        
            this.fundraisersPerStatus = []; 
            await this.$apollo.query({
                query: FUNDRAISER_BY_STATUS_QUERY,
                variables: {
                    status: this.status,
                },
                fetchPolicy: 'network-only'
                }).then(response => {
                    this.fundraisersPerStatus = response.data.fundraisersPerStatus
                })
        },
        preview(request) {
            TokenService.setRequest(request);
            this.$router.push("/preview");
        },
        donationPercentage(amount, goal) {
            return (amount / goal) * 100;
        },
       async updateStatus(status, id) {
           await this.$apollo
                .mutate({
                    mutation: EDIT_FUNDRAISER_MUTATION,
                    variables: {
                        input: {
                            id: id,
                            status: status,
                        }
                    }
                })
            this.$swal({
                title: 'Fundraiser status updated sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
            });
            await this.statusChange("1"); 
        },
        
    },
    async created() {
        await this.statusChange("1"); 
    }

}
</script>
