<template>
    <div class="app-admin-wrap layout-horizontal-bar">
        <Sidebar />
        <Topbar />
        <div class="main-content-wrap d-flex flex-column">
            <div class="main-content">
                <Breadcrumbs />
                <div class="separator-breadcrumb border-top"></div>
                <div class="row mb-4">
                    <div class="col-md-12">
                        <div class="card o-hidden mb-4">
                            <div class="card-body">
                                <!-- <div class="ul-widget__head">
                                    <div class="ul-widget__head-label">
                                        <h3 class="ul-widget__head-title">Gift Aid</h3>
                                    </div>
                                </div> -->
                                <div v-if="donationRequestsPerStatus.length > 0"  class="ul-widget__body">
                                    <div class="tab-content">
                                        <div class="tab-pane active show" id="ul-widget5-tab1-content">
                                            <div class="ul-widget5">
                                                <div v-for="requestdon in donationRequestsPerStatus" :key="requestdon._id" class="ul-widget-s5__item mb-5">
                                                <div class="ul-widget-s5__content">
                                                    <div class="ul-widget5__pic"><img id="userDropdown"
                                                            v-bind:src="requestdon.member.profilePhoto" alt=""
                                                            data-toggle="dropdown" aria-haspopup="true"
                                                            aria-expanded="false" /></div>
                                                    <div class="ul-widget-s5__section"><a class="ul-widget4__title"
                                                            href="#">Product: {{ requestdon.product.product_name.toUpperCase() }}</a>
                                                            <p class="ul-widget-s5__desc"><b>Category:</b>
                                                           {{ requestdon.category.category_name.toUpperCase() }}</p>
                                                        <p class="ul-widget-s5__desc"><b>Requester:</b>
                                                            {{ requestdon.member.first_name.toUpperCase() + " " +
                                                                requestdon.member.last_name.toUpperCase() }} ({{ requestdon.member.country.country_name.toUpperCase() }})</p>
                                                    </div>
                                                </div>
                                                <div class="ul-widget-s5__content">
                                                    <div class="ul-widget-s5__progress">
                                                        <div class="ul-widget-s5__stats"><span> $ {{requestdon.donatedAmount }}</span><span>$ {{requestdon.amount }}</span></div>
                                                        <div class="progress mb-3">
                                                            <div :class="donationPercentage(requestdon.donatedAmount, requestdon.amount) < '50' ? 'progress-bar progress-bar-striped bg-danger' : (donationPercentage(requestdon.donatedAmount, requestdon.amount) > '90' ? 'progress-bar progress-bar-striped bg-success' : 'progress-bar progress-bar-striped bg-Primary')"
                                                                role="progressbar"
                                                                :style="{ 'width': donationPercentage(requestdon.donatedAmount, requestdon.amount) + '%' }"
                                                                aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                        </div>
                                                    </div>
                                                    <button class="btn btn-outline-info" type="button" @click="donate(requestdon)">DONATE</button>
                                                    <button   class="btn btn-outline-success ul-btn-raised--v2 m-1 float-end"
                                                        type="button" @click="preview(requestdon)">PREVIEW</button>
                                                </div>
                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div v-if="donationRequestsPerStatus.length == 0" class="row">
                                    <div class="user-profile mb-4">
                                        <div class="ul-widget-card__user-info">
                                            <img class="profile-picture avatar-lg mb-2 mt-2"
                                                src="https://cdn.pixabay.com/photo/2014/12/21/23/57/money-576443_1280.png"
                                                alt="" />

                                        </div>
                                        <div class="ul-widget-card--line text-center mt-2">
                                            <a type="button" data-bs-toggle="modal" data-target="#verifyModalContent"
                                                data-whatever="@mdo"> No fundraiser yet please check later!</a>
                                        </div>
                                    </div>
                                </div>
                               
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex-grow-1"></div>
            <Footer />
        </div>
    </div>
</template>
  
<script>
import TokenService from "@/services/token.service";
import Topbar from "@/components/partials/Topbar.vue";
import Footer from "@/components/partials/Footer.vue";
import Sidebar from "@/components/partials/Sidebar";
import Breadcrumbs from "@/components/partials/Breadcrumbs";
import { REQUESTSTATUS_QUERY, ADD_DONATION_MUTATION} from '@/graphql';
export default {
    name: "Request",
    components: { Sidebar, Topbar, Footer, Breadcrumbs},
    data() {
        return {
            donationRequestsPerStatus: [],
            amount: '',
            request_id: '',
            currentuser: TokenService.getUser(),
        }
    },
    apollo: {
        // fetch all donations
        donationRequestsPerStatus: {
            query: REQUESTSTATUS_QUERY,
            variables: {
                status: "2"
            }
        }
    },
    methods: {
        donate(request){
            this.$swal({
            title: 'Specify Donation Amount',
            icon: 'info',
            showCloseButton: true,
            showCancelButton: true,
            confirmButtonText: 'Donate',
            cancelButtonText: 'Cancel',
            input: 'number',
            inputLabel: 'Donation Amount',
            inputAttributes: {
                step: 0.01,
                max: request.amount 
            },
            inputValidator: (value) => {
                if (!value) {
                return 'Amount is required'
                }
                else{
                this.$swal({
                    title: 'Do you want to donate $'+ value + '?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.$apollo
                .mutate({
                    mutation: ADD_DONATION_MUTATION,
                    variables: {
                        donarId: this.currentuser._id,
                        donationRequestId: request._id,
                        amount: value,
                    }
                })
                .then(response => {
                    // redirect user
                    this.$swal({
                        title: 'Donation added to cart',
                        position: 'top-end',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    this.$router.push("/donation-cart");
                }).catch((error) => {
                    this.$swal({
                        title: error.message,
                        position: "top-end",
                        icon: "warning",
                        showConfirmButton: false,
                        timer: 3000,
                    });
                })
                    }
                })
                }
            }
            })
        },
        donationPercentage(amount, goal) {
            return (amount/goal)*100;
            },
        preview(request) {
            TokenService.setRequest(request);
            this.$router.push("/gift-aid-preview");
        },
    }

}
</script>
  