<template>
  <div class="app-admin-wrap layout-horizontal-bar">
    <Sidebar />
    <Topbar />
    <div class="main-content-wrap d-flex flex-column">
      <div class="main-content">
        <Breadcrumbs />
        <div class="separator-breadcrumb border-top"></div>
        <div class="row">
          <div class="card">
            <div class="card-body">
              <div v-if="currentuser.donations.length > 0" class="table-responsive">
                <table class="table align-items-center mb-5" id="donation-table" style="width: 100%">
                  <thead>
                    <tr class="bg-primary text-white">
                      <th scope="col">DONATION CODE</th>                      
                      <th scope="col">AMOUNT</th>
                      <th scope="col">DONATED TO</th>
                      <th scope="col">REQUEST GOAL</th>
                      <!-- <th scope="col">STATUS</th> -->
                      <th scope="col">DATE</th>
                      <th scope="col">ACTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr v-for="requestdon, index in currentuser.donations" :key="requestdon._id">
                      <td>{{ requestdon.donation_code }}</td>
                      <td>$ {{ requestdon.amount }}</td>
                      <td>{{ (requestdon.donationRequests != null) ? requestdon.donationRequests.member.first_name.toUpperCase() +" "+ requestdon.donationRequests.member.last_name.toUpperCase() : 
                      requestdon.fundraiser.member.first_name.toUpperCase() +" "+ requestdon.fundraiser.member.last_name.toUpperCase()}}
                        </td>
                      <td>$ {{ (requestdon.donationRequests != null) ? requestdon.donationRequests.amount : 
                        requestdon.fundraiser.amount}}
                      </td>
                      <!-- <td>$ {{ (requestdon.donationRequests != null) ? decimal(requestdon.donationRequests.donatedAmount) : 
                        requestdon.fundraiser.donatedAmount}}
                      </td> -->
                      <td>{{ formatDate(requestdon.createdAt) }}</td>
                      <td>
                        <!-- {{ (requestdon.donationRequests != null) ? requestdon.donationRequests.amount : 
                        requestdon.fundraiser.amount}} -->
                        <button v-if="(requestdon.donationRequests != null && requestdon.donationRequests.status == '2') || (requestdon.fundraiser != null && requestdon.fundraiser.status == '2')"  class="btn btn-outline-success ul-btn-raised--v2 m-1 float-end" type="button"
                          @click="redonate(requestdon)">REDONATE</button>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div v-if="currentuser.donations.length == 0" class="user-profile mb-4">
                <div class="ul-widget-card__user-info">
                  <img class="profile-picture avatar-lg mb-2 mt-2"
                    src="https://cdn.pixabay.com/photo/2014/12/21/23/57/money-576443_1280.png" alt="" />

                </div>
                <div class="ul-widget-card--line text-center mt-2">
                  <a type="button"> No donations yet please look at existing fundraisers and Gift Aids to donate!</a>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
      <div class="flex-grow-1"></div>
      <Footer />
    </div>
  </div>
</template>
  
<script>
import TokenService from "@/services/token.service";
import Topbar from "@/components/partials/Topbar.vue";
import Footer from "@/components/partials/Footer.vue";
import Sidebar from "@/components/partials/Sidebar";
import Breadcrumbs from "@/components/partials/Breadcrumbs";
import { CURRENT_USER_DONATIONS, ADD_DONATION_MUTATION, DONATE_FUNDRAISER_MUTATION } from '@/graphql';

import "datatables.net-dt/js/dataTables.dataTables";
import "@/assets/css/dataTables.bootstrap4.min.css";
import "@/assets/css/buttons.dataTables.min.css";
import "datatables.net-buttons/js/dataTables.buttons.js";
import "datatables.net-buttons/js/buttons.colVis.js";
import "datatables.net-buttons/js/buttons.flash.js";
import "datatables.net-buttons/js/buttons.html5.js";
import "datatables.net-buttons/js/buttons.print.js";
import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
pdfMake.vfs = pdfFonts.pdfMake.vfs;
import moment from 'moment'

import "@/assets/datatables/jquery.dataTables.min.js";
import "@/assets/datatables/dataTables.bootstrap4.min.js";
import "@/assets/datatables/dataTables.buttons.min.js";
import "@/assets/datatables/buttons.html5.min.js";
import "@/assets/datatables/buttons.print.min.js";
import "@/assets/datatables/jszip.min.js";
export default {
  name: "Donation",
  components: { Sidebar, Topbar, Footer, Breadcrumbs },
  data() {
    return {
      donations: [],
      amount: '',
      donarId: '',
      donationRequestId: '',
      request: [],
      currentuser: [],
      requestDonated: [],
    }
  },
  methods: {
    preview(request) {
      TokenService.setRequest(request);
      this.$router.push("/preview");
    },
    donationPercentage(amount, goal) {
      return (amount / goal) * 100;
    },
    decimal(number){
         return parseFloat(number)
    },
    redonate(donation) {
      console.log(donation);
      if((donation.donationRequests != null)){
        this.$swal({
        title: 'Confirm the Donation Amount',
        icon: 'info',
        showCloseButton: true,
        showCancelButton: true,
        confirmButtonText: 'Donate',
        cancelButtonText: 'Cancel',
        input: 'number',
        inputLabel: 'Donation Amount',
        inputValue: donation.amount,
        inputAttributes: {
          step: 0.01,
          max: donation.donationRequests.amount - donation.donationRequests.donatedAmount
        },
        inputValidator: (value) => {
          if (!value) {
            return 'Amount is required'
          }
          else {
            this.$swal({
              title: 'Do you want to donate $' + value + '?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes!'
            }).then((result) => {
              if (result.isConfirmed) {
                this.$apollo
                .mutate({
                    mutation: ADD_DONATION_MUTATION,
                    variables: {
                        donarId: this.currentuser._id,
                        donationRequestId: donation.donationRequests._id,
                        amount: value,
                    }
                })
                .then(response => {
                    // redirect user
                    this.$swal({
                        title: 'Donation added to cart',
                        position: 'top-end',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    this.$router.push("/donation-cart");
                }).catch((error) => {
                    this.$swal({
                        title: error.message,
                        position: "top-end",
                        icon: "warning",
                        showConfirmButton: false,
                        timer: 3000,
                    });
                })
              }
            })
          }
        }
      })

      }else{
        this.$swal({
        title: 'Confirm the Donation Amount',
        icon: 'info',
        showCloseButton: true,
        showCancelButton: true,
        confirmButtonText: 'Donate',
        cancelButtonText: 'Cancel',
        input: 'number',
        inputLabel: 'Donation Amount',
        inputValue: donation.amount,
        inputAttributes: {
          step: 0.01,
          max: donation.fundraiser.amount - donation.fundraiser.donatedAmount
        },
        inputValidator: (value) => {
          if (!value) {
            return 'Amount is required'
          }
          else {
            this.$swal({
              title: 'Do you want to donate $' + value + '?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes!'
            }).then((result) => {
              if (result.isConfirmed) {
                this.$apollo
                .mutate({
                    mutation: DONATE_FUNDRAISER_MUTATION,
                    variables: {
                        donarId: this.currentuser._id,
                        fundraiserId: donation.fundraiser._id,
                        amount: value,
                    }
                })
                .then(response => {
                    // redirect user
                    this.$swal({
                        title: 'Donation added to cart',
                        position: 'top-end',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    this.$router.push("/donation-cart");
                }).catch((error) => {
                    this.$swal({
                        title: error.message,
                        position: "top-end",
                        icon: "warning",
                        showConfirmButton: false,
                        timer: 3000,
                    });
                })
              }
            })
          }
        }
      })
      }
    },
    formatDate(created) {
      return moment(created).format('MMMM Do YYYY, h:mm:ss a')
    },
    async loadData() {
      await this.$apollo.query({
        query: CURRENT_USER_DONATIONS,
        fetchPolicy: 'network-only'
      }).then(response => {
        this.currentuser = response.data.currentuser;
      })
      setTimeout(function () {
        $("#donation-table").DataTable({
          destroy: true,
          pageLength: 5,
          lengthChange: true,
          processing: true,
          paging: true,
          info: false,
          dom: "Bfrtip",
          buttons: [
            { extend: 'csv', text: '<i class="fa-solid fa-file-pdf"></i>', className: 'btn btn-sm btn-outline-success mb-3 text-success' },
            { extend: 'pdf', text: '<i class="fa fa-file-pdf"></i>', className: 'btn btn-sm btn-outline-danger mb-3 text-danger' },
            { extend: 'print', text: '<i class="fa fa-print"></i>', className: 'btn btn-sm btn-outline-secondary mb-3 text-secondary' }
          ]
        });
      }, 300);
    }
  },
  async created() {
    await this.loadData()
  }

}
</script>