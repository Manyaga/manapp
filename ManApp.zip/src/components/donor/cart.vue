<template>
    <div class="app-admin-wrap layout-horizontal-bar">
        <Sidebar />
        <Topbar />
        <div class="main-content-wrap d-flex flex-column">
            <div class="main-content">
                <Breadcrumbs />
                <div class="separator-breadcrumb border-top"></div>
                <section class="product-cart">
                    <div class="row">
                        <div class="col-lg-12">
                            <ul class="nav nav-tabs justify-content-end mb-4" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="invoice-tab" data-bs-toggle="tab" href="#invoice"
                                        role="tab" aria-controls="invoice" aria-selected="true">Product Aids</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="edit-tab" data-bs-toggle="tab" href="#edit" role="tab"
                                        aria-controls="edit" aria-selected="false">Fundraisers</a>
                                </li>
                            </ul>
                            <div class="card">
                                <div class="tab-content" id="myTabContent">
                                    <div class="tab-pane fade show active" id="invoice" role="tabpanel"
                                        aria-labelledby="invoice-tab">
                                        <div v-if="requests.length > 0" class="card-body">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h4 class="fw-bold text-primary">Donation Cart</h4>
                                                </div>
                                                <div class="col-md-6 text-sm-end">
                                                    <p><strong>Date: </strong>{{ timeNow }}</p>
                                                </div>
                                            </div>
                                            <!-- <div class="mt-3 mb-4 border-top"></div> -->
                                            <div class="row mb-5">
                                                <div class="col-md-6 mb-3 mb-sm-0">
                                                    <h5 class="fw-bold">DONOR</h5>
                                                    <p>{{ currentuser.first_name.toUpperCase() }} {{
                                                        currentuser.last_name.toUpperCase() }}</p>
                                                </div>
                                                <div class="col-md-6 text-sm-end">
                                                    <h5 class="fw-bold">County</h5>
                                                    <p>{{ currentuser.country.country_name.toUpperCase() }}</p>
                                                </div>
                                            </div>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead class="bg-gray-300">
                                                        <tr>
                                                            <th scope="col">#</th>
                                                            <th scope="col">Product</th>
                                                            <th scope="col">Goal</th>
                                                            <th scope="col">Received</th>
                                                            <th scope="col">Donation Code</th>
                                                            <th scope="col">My Donation</th>
                                                            <th scope="col">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr v-for="requestdon, index in requests" :key="requestdon._id">
                                                            <td>{{ index + 1 }}</td>
                                                            <td scope="row"><img
                                                                    class="profile-picture avatar-sm mb-2 img-fluid"
                                                                    src="../../assets/images/products/speaker-1.jpg"
                                                                    alt="" />
                                                                <div
                                                                    class="ul-product-cart__detail d-inline-block align-middle ms-1">
                                                                    <a href="">
                                                                        <h5 class="heading">
                                                                            {{
                                                                                requestdon.donationRequests.product.product_name.toUpperCase()
                                                                            }}</h5>
                                                                    </a><span class="text-mute font-size-200">{{
                                                                        requestdon.donationRequests.category.category_name
                                                                    }}</span>
                                                                </div>
                                                            </td>
                                                            <td>${{ requestdon.donationRequests.amount }}</td>
                                                            <td>${{ requestdon.donationRequests.donatedAmount }}</td>
                                                            <td>{{ requestdon.donation_code }}</td>
                                                            <td>${{ requestdon.amount }}</td>
                                                            <td><a class="text-danger me-2" href="#"
                                                                    @click="deleteDonation(requestdon._id)">
                                                                    <i class="nav-icon i-Close-Window fw-bold"></i></a></td>
                                                        </tr>
                                                    </tbody>
                                                </table>


                                            </div>
                                            <div class="col-md-12">
                                                <div class="invoice-summary">
                                                    <!-- <p>Received: <span>$ {{Number(productAid.donatedAmount).toLocaleString()}}</span></p> -->
                                                    <h5 class="fw-bold text-16">
                                                        <span class="text-primary text-16" scope="row"> TOTAL: </span><span
                                                            class="font-weight-700 text-16">$ {{ calculateTotal() }}</span>
                                                    </h5>
                                                    <button class="btn btn-primary ripple m-1" @click="updateStatus()"
                                                        type="button">Checkout</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div v-if="requests.length == 0" class="card-body">
                                            <div class="user-profile mb-4">
                                                <div class="ul-widget-card__user-info">
                                                    <img class="profile-picture avatar-lg mb-2"
                                                        src="https://cdn.pixabay.com/photo/2016/05/25/20/17/icon-1415760__480.png"
                                                        alt="" />

                                                </div>
                                                <div class="ul-widget-card--line text-center  mt-2">
                                                    <RouterLink to="all-requests"><a class="m-1" type="button">
                                                            No donations in the cart yet, click here to Donate!</a>
                                                    </RouterLink>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="edit" role="tabpanel" aria-labelledby="edit-tab">
                                        <div v-if="fundraisers.length > 0" class="card-body">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h4 class="fw-bold text-primary">Donation Cart</h4>
                                                </div>
                                                <div class="col-md-6 text-sm-end">
                                                    <p><strong>Date: </strong>{{ timeNow }}</p>
                                                </div>
                                            </div>
                                            <!-- <div class="mt-3 mb-4 border-top"></div> -->
                                            <div class="row mb-5">
                                                <div class="col-md-6 mb-3 mb-sm-0">
                                                    <h5 class="fw-bold">DONOR</h5>
                                                    <p>{{ currentuser.first_name.toUpperCase() }} {{
                                                        currentuser.last_name.toUpperCase() }}</p>
                                                </div>
                                                <div class="col-md-6 text-sm-end">
                                                    <h5 class="fw-bold">County</h5>
                                                    <p>{{ currentuser.country.country_name.toUpperCase() }}</p>
                                                </div>
                                            </div>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <thead class="bg-gray-300">
                                                        <tr>
                                                            <th scope="col">#</th>
                                                            <th scope="col">Code</th>
                                                            <th scope="col">Story</th>
                                                            <th scope="col">Amount</th>
                                                            <th scope="col">Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr v-for="requestdon, index in fundraisers" :key="requestdon._id">
                                                            <td>{{ index + 1 }}</td>
                                                            <td scope="row"><img
                                                                    class="profile-picture avatar-sm mb-2 img-fluid"
                                                                    src="../../assets/images/products/speaker-1.jpg"
                                                                    alt="" />
                                                                <div
                                                                    class="ul-product-cart__detail d-inline-block align-middle ms-1">
                                                                    <a href="">
                                                                        <h5 class="heading">
                                                                            {{
                                                                                requestdon.fundraiser.request_code.toUpperCase()
                                                                            }}</h5>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                            <td>{{ requestdon.fundraiser.story }}</td>
                                                            <td>$ {{ Number(requestdon.amount).toLocaleString() }}</td>
                                                            <td><a class="text-danger me-2" href="#"
                                                                    @click="deleteFundraiser(requestdon._id)">
                                                                    <i class="nav-icon i-Close-Window fw-bold"></i></a></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="invoice-summary">
                                                    <!-- <p>Received: <span>$ {{Number(productAid.donatedAmount).toLocaleString()}}</span></p> -->
                                                    <h5 class="fw-bold text-16">
                                                        <span class="text-primary text-16" scope="row"> TOTAL: </span><span
                                                            class="font-weight-700 text-16">$ {{ fundraiserTotal() }}</span>
                                                    </h5>
                                                    <button class="btn btn-primary ripple m-1" @click="updateFundraisers()"
                                                        type="button">Checkout</button>
                                                </div>
                                            </div>

                                        </div>
                                        <div v-if="fundraisers.length == 0" class="card-body">
                                            <div class="user-profile mb-4">
                                                <div class="ul-widget-card__user-info">
                                                    <img class="profile-picture avatar-lg mb-2"
                                                        src="https://cdn.pixabay.com/photo/2016/05/25/20/17/icon-1415760__480.png"
                                                        alt="" />

                                                </div>
                                                <div class="ul-widget-card--line text-center  mt-2">
                                                    <RouterLink to="all-fundraisers"><a class="m-1" type="button">
                                                            No fundraiser in cart, click here to launch a fundraiser!</a>
                                                    </RouterLink>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section><!-- end of main-content -->
            </div>
            <div class="flex-grow-1"></div>
            <Footer />
        </div>
    </div>
</template>
    
<script>
import Topbar from "@/components/partials/Topbar.vue";
import Footer from "@/components/partials/Footer.vue";
import Sidebar from "@/components/partials/Sidebar";
import Breadcrumbs from "@/components/partials/Breadcrumbs";
import moment from 'moment'
import TokenService from "@/services/token.service";
import { EDIT_DONATION_MUTATION, FILTER_DONATION_QUERY, EDIT_FUNDRAISER_DONATION_MUTATION, DELETE_DONATION_MUTATION } from '@/graphql';
export default {
    name: "ProductCart",
    components: { Sidebar, Topbar, Footer, Breadcrumbs },
    data() {
        return {
            filteredDonations: [],
            requests: [],
            fundraisers: [],
            amount: '',
            quantity: '',
            total: 0,
            requestID: '',
            message: '',
            currentuser: TokenService.getUser(),
        }
    },
    methods: {
        calculateTotal() {
            this.total = 0;
            for (var i = 0; i < this.filteredDonations.length; i++) {
                this.total += (Number(this.filteredDonations[i].amount))
            }
            return this.total.toFixed(2)
        },
        fundraiserTotal() {
            this.total = 0;
            for (var i = 0; i < this.fundraisers.length; i++) {
                this.total += (Number(this.fundraisers[i].amount))
            }
            return this.total.toLocaleString()
        },
        updateStatus() {
            for (var i = 0; i < this.filteredDonations.length; i++) {
                this.$apollo
                    .mutate({
                        mutation: EDIT_DONATION_MUTATION,
                        variables: {
                            input: {
                                id: this.filteredDonations[i]._id,
                                status: '1',
                            }
                        }
                    })
            }
            this.$swal({
                title: 'Donation(s) added sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
            });
            this.$router.push("/my-donations");
        },
        async updateFundraisers() {
            for (var i = 0; i < this.fundraisers.length; i++) {
                await this.$apollo
                    .mutate({
                        mutation: EDIT_FUNDRAISER_DONATION_MUTATION,
                        variables: {
                            input: {
                                id: this.fundraisers[i]._id,
                                status: '1',
                            }
                        }
                    })
            }
            await this.$swal({
                title: 'Fundraiser(s) added sucessfully',
                position: 'top-end',
                icon: 'success',
                showConfirmButton: false,
                timer: 2000
            });
            this.$router.push("/all-fundraisers");
        },
        deleteDonation(donation_id) {
            this.$swal({
                title: "Remove donation from cart?",
                icon: "warning",
                showCancelButton: true,
                confirmButtonColor: "#3085d6",
                cancelButtonColor: "#d33",
                confirmButtonText: "Remove!",
            }).then((result) => {
                if (result.isConfirmed) {
                    this.$apollo
                        .mutate({
                            mutation: DELETE_DONATION_MUTATION,
                            variables: {
                                donationId: donation_id,
                            }
                        })
                        .then(response => {
                            this.$swal({
                                title: 'Donation deleted sucessfully',
                                position: 'top-end',
                                icon: 'success',
                                showConfirmButton: false,
                                timer: 2000
                            });
                            this.$apollo.queries.donations.refetch()
                        }).catch((error) => {
                            this.$swal({
                                title: error.message,
                                position: "top-end",
                                icon: "warning",
                                showConfirmButton: false,
                                timer: 3000,
                            });
                        })
                }
            });
        },
        requestDonations() {
            let donations = this.filteredDonations
            return donations.filter(function (u) {
                return u.donationRequests != null
            })
        },
        fundraiserDonations() {
            let donations = this.filteredDonations
            return donations.filter(function (u) {
                return u.fundraiser != null
            })
        },
    },
    async created() {
        console.log(this.filteredDonations)
        await this.$apollo.query({
            query: FILTER_DONATION_QUERY,
            variables: {
                status: '0'
            },
            fetchPolicy: 'network-only'
        }).then(response => {
            this.filteredDonations = response.data.filteredDonations
        })
        this.requests = this.requestDonations()
        this.fundraisers = this.fundraiserDonations()
    },
    computed: {
        timeNow: function () {
            return moment().format('MMMM Do YYYY')
        }
    },

}
</script>