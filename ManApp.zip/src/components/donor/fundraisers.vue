<template>
    <div class="app-admin-wrap layout-horizontal-bar">
        <Sidebar />
        <Topbar />
        <div class="main-content-wrap d-flex flex-column">
            <div class="main-content">
                <Breadcrumbs />
                <div class="separator-breadcrumb border-top"></div>
                <div class="row mb-4">
                    <div class="col-md-12">
                        <div class="card o-hidden mb-4">
                            <div class="card-body">
                                <div v-if="fundraisersPerStatus.length > 0" class="row mb-4">
                                    <!-- <div class="ul-widget__head">
                                <div class="ul-widget__head-label">
                                    <h3 class="ul-widget__head-title">Fundraise Request</h3>
                                </div>
                            </div> -->
                                    <div class="col-lg-4 col-xl-4 mt-3" v-for="requestdon in fundraisersPerStatus"
                                        :key="requestdon._id">
                                        <div class="card">
                                            <div class="card-body"><img class="d-block w-100 rounded"
                                                    v-bind:src="requestdon.member.profilePhoto" alt="First slide" />
                                                <div class="ul-widget-card__progress-rate"><span>$ {{
                                                    requestdon.donatedAmount }}</span><span>$ {{requestdon.amount }}</span></div>
                                                <div class="progress progress--height mb-3">
                                                    <div :class="donationPercentage(requestdon.donatedAmount, requestdon.amount) < '50' ? 'progress-bar progress-bar-striped bg-danger' : (donationPercentage(requestdon.donatedAmount, requestdon.amount) > '90' ? 'progress-bar progress-bar-striped bg-success' : 'progress-bar progress-bar-striped bg-Primary')"
                                                        role="progressbar"
                                                        :style="{ 'width': donationPercentage(requestdon.donatedAmount, requestdon.amount) + '%' }"
                                                        aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                                <h5 class="card-title mt-4 mb-2">{{
                                                    requestdon.member.first_name.toUpperCase()
                                                    + " " + requestdon.member.last_name.toUpperCase() }}</h5>
                                                <p class="card-text text-mute">{{ requestdon.story }}</p>
                                                <div class="ul-widget-card__full-status mb-3">
                                                    <button class="btn btn-outline-success" type="button" @click="donate(requestdon)">DONATE</button>
                                                    <button 
                                                        class="btn btn-outline-primary text-secondary ul-btn-raised--v2 m-1 float-end"
                                                        type="button" @click="preview(requestdon)">PREVIEW</button>
                                                        
                                                </div>
                                                <div class="separator-breadcrumb border-top"></div>
                                                <div class="ul-widget-card__rate-icon">
                                                    <span>
                                                        <p class="text-small font-italic"><i
                                                                class="i-Map-Marker text-warning"></i>{{
                                                                    requestdon.member.country.country_name.toUpperCase() }}</p>
                                                    </span>
                                                    <span>
                                                        <p class="text-small font-italic"><i
                                                                class="i-Telephone text-primary"></i>
                                                            {{ requestdon.member.phone_number }}</p>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div v-if="fundraisersPerStatus.length == 0" class="row">
                                    <div class="user-profile mb-4">
                                        <div class="ul-widget-card__user-info">
                                            <img class="profile-picture avatar-lg mb-2 mt-2"
                                                src="https://cdn.pixabay.com/photo/2014/12/21/23/57/money-576443_1280.png"
                                                alt="" />

                                        </div>
                                        <div class="ul-widget-card--line text-center mt-2">
                                            <a type="button" data-bs-toggle="modal" data-target="#verifyModalContent"
                                                data-whatever="@mdo"> No fundraiser yet please check later!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex-grow-1"></div>
            <Footer />
        </div>
    </div>
</template>

<script>
import TokenService from "@/services/token.service";
import Topbar from "@/components/partials/Topbar.vue";
import Footer from "@/components/partials/Footer.vue";
import Sidebar from "@/components/partials/Sidebar";
import Breadcrumbs from "@/components/partials/Breadcrumbs";

import { FUNDRAISER_BY_STATUS_QUERY, DONATE_FUNDRAISER_MUTATION } from '@/graphql';
export default {
    name: "Request",
    components: { Sidebar, Topbar, Footer, Breadcrumbs },
    data() {
        return {
            fundraisersPerStatus: [],
            amount: '',
            story: '',
            currentuser: TokenService.getUser(),
        }
    },
    apollo: {
        // fetch all donations
        fundraisersPerStatus: {
            query: FUNDRAISER_BY_STATUS_QUERY,
            variables: {
                status: "2"
            }
        }
    },
    methods: {
        donate(request){
            this.$swal({
            title: 'Specify Donation Amount',
            icon: 'info',
            showCloseButton: true,
            showCancelButton: true,
            confirmButtonText: 'Donate',
            cancelButtonText: 'Cancel',
            input: 'number',
            inputLabel: 'Donation Amount',
            inputAttributes: {
                step: 0.01,
                max: request.amount 
            },
            inputValidator:(value) => {
                if (!value) {
                return 'Amount is required'
                }
                else{
                this.$swal({
                    title: 'Do you want to donate $'+ value + '?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes!'
                }).then( async  (result) => {
                    if (result.isConfirmed) {
                       await this.$apollo
                .mutate({
                    mutation: DONATE_FUNDRAISER_MUTATION,
                    variables: {
                        donarId: this.currentuser._id,
                        fundraiserId: request._id,
                        amount: value,
                    }
                })
                .then( async  response => {
                    // redirect user
                    await this.$swal({
                        title: 'Donation added to cart',
                        position: 'top-end',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    this.$router.push("/donation-cart");
                }).catch((error) => {
                    this.$swal({
                        title: error.message,
                        position: "top-end",
                        icon: "warning",
                        showConfirmButton: false,
                        timer: 3000,
                    });
                })
                    }
                })
                }
            }
            })
        },
        preview(request) {
            TokenService.setRequest(request);
            this.$router.push("/preview");
        },
        donationPercentage(amount, goal) {
            return (amount / goal) * 100;
        },
    },
    async created() {

    }

}
</script>
