<template>
  <div class="app-admin-wrap layout-horizontal-bar">
    <Sidebar />
    <Topbar />
    <div class="main-content-wrap d-flex flex-column">
      <div class="main-content">
        <Breadcrumbs />
        <div class="separator-breadcrumb border-top"></div>
        <div class="row mb-4">
          <div class="card">
            <div class="tab-content" id="myTabContent">
              <div class="tab-pane fade show active" id="invoice" role="tabpanel" aria-labelledby="invoice-tab">
                <div class="d-sm-flex mb-5" data-view="print">
                  <span class="m-auto"></span>
                  <button v-if="currentuser.role._id == '63fd059321a945fd564e9c6e'"  @click="donate(productAid)" class="btn btn-success mb-sm-0 mb-3 print-invoice">
                    Donate
                  </button>
                </div>
                <!-- -===== Print Area =======-->
                <div id="print-area">
                  <div class="row">
                    <div class="col-md-6">
                      <h4 class="fw-bold">Request Code</h4>
                      <p>#{{ productAid.request_code }}</p>
                    </div>
                    <div class="col-md-6 text-sm-end">
                      <p><strong>Order status: </strong>{{ orderStatus() }}</p>
                      <p><strong>Launched: </strong>{{ formatDate(productAid.createdAt) }}</p>
                    </div>
                  </div>
                  <div class="mt-3 mb-4 border-top"></div>
                  <div class="row mb-5">
                    <div class="col-md-6 mb-3 mb-sm-0">
                      <h5 class="fw-bold">Requester</h5>
                      <p>{{ productAid.member.first_name.toUpperCase() }} {{ productAid.member.last_name.toUpperCase() }}</p>
                      <span style="white-space: pre-line">
                        <b>Country:</b> {{ productAid.member.country.country_name.toUpperCase() }}
                      </span>
                    </div>
                    <div class="col-md-6 text-sm-end">
                      <h5 class="fw-bold">Product</h5>
                      <p>{{ productAid.product.product_name.toUpperCase() }}</p>
                      <b>Category:</b> <span style="white-space: pre-line">
                        {{ productAid.category.category_name.toUpperCase() }}
                      </span>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12 table-responsive">
                      <table class="table table-hover mb-4">
                        <thead class="bg-gray-300">
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col"></th>
                            <th scope="col">Donor</th>
                            <th scope="col">Time</th>
                            <th scope="col">Amount</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr v-for="(donor,index) in productAid.donations" :value="donor._id" :key="donor._id">
                                <th scope="row">{{index+1}}</th>
                                <td><img class="rounded-circle m-0 avatar-sm-table"  v-bind:src="donor.donar.profilePhoto" alt="" /></td>
                                <td>{{donor.donar.first_name.toUpperCase() + " " + donor.donar.last_name.toUpperCase()}}</td>
                                <td>{{formatDate(donor.createdAt)}}</td>
                                <td>$ {{donor.amount}}</td>
                            </tr>
                        </tbody>
                      </table>
                    </div>
                    <div class="col-md-12">
                      <div class="invoice-summary">
                        <p>Received: <span>$ {{Number(productAid.donatedAmount).toLocaleString()}}</span></p>
                        <h5 class="fw-bold">
                          Goal: <span>$ {{Number(productAid.amount).toLocaleString()}}</span>
                        </h5>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- ==== / Print Area =====-->
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="flex-grow-1"></div>
      <Footer />
    </div>
  </div>
</template>

<script>
import Topbar from "@/components/partials/Topbar.vue";
import Footer from "@/components/partials/Footer.vue";
import Sidebar from "@/components/partials/Sidebar";
import Breadcrumbs from "@/components/partials/Breadcrumbs";
import TokenService from "@/services/token.service";
import moment from 'moment'
import { ADD_DONATION_MUTATION} from '@/graphql';
export default {
  name: "FundraiserPreview",
  components: { Sidebar, Topbar, Footer, Breadcrumbs },
  data() {
    return {
      productAid: TokenService.getRequest(),
      currentuser: TokenService.getUser(),
    }
  },
  methods: {
    donationPercentage(goal, amount) {
      return (amount / goal) * 100;
    },
    formatDate(created) {
      let formartedDate =  moment(created).format('YYYY-MM-DD HH:mm')
      console.log(created)
      return moment(formartedDate, "YYYY-MM-DD HH:mm").fromNow();
    },
    orderStatus() {
      return (this.productAid.status == "2") ? "IN PROGRESS" : ((this.productAid.status == "3") ? "CLOSED" : "REJECTED")
    },
    donationPercentage(amount, goal) {
      return (amount/goal)*100;
      },
      donate(request){
            this.$swal({
            title: 'Specify Donation Amount',
            icon: 'info',
            showCloseButton: true,
            showCancelButton: true,
            confirmButtonText: 'Donate',
            cancelButtonText: 'Cancel',
            input: 'number',
            inputLabel: 'Donation Amount',
            inputAttributes: {
                step: 0.01,
                max: request.amount 
            },
            inputValidator: (value) => {
                if (!value) {
                return 'Amount is required'
                }
                else{
                this.$swal({
                    title: 'Do you want to donate $'+ value + '?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        this.$apollo
                .mutate({
                    mutation: ADD_DONATION_MUTATION,
                    variables: {
                        donarId: this.currentuser._id,
                        donationRequestId: request._id,
                        amount: value,
                    }
                })
                .then(response => {
                    // redirect user
                    this.$swal({
                        title: 'Donation added to cart',
                        position: 'top-end',
                        icon: 'success',
                        showConfirmButton: false,
                        timer: 2000
                    });
                    this.$router.push("/donation-cart");
                }).catch((error) => {
                    this.$swal({
                        title: error.message,
                        position: "top-end",
                        icon: "warning",
                        showConfirmButton: false,
                        timer: 3000,
                    });
                })
                    }
                })
                }
            }
            })
        },
  },
  created() {
  }

}
</script>
