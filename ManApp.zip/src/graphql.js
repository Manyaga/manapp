import gql from 'graphql-tag'

export const SIGNUP_MUTATION = gql`
  mutation SignupMutation($username: String!, $email: String!, $password: String!) {
    createUser(
      username: $username,
      email: $email,
      password: $password
    ) {
      id
      username
      email
    }
  }
`
export const LOGIN_MUTATION = gql`
mutation Mutation($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      token
    }
  }
`
export const LOGIOUT_MUTATION = gql`
query Logoutuser {
  logoutuser {
    token
  }
}
`
export const USER_QUERY = gql`
query Currentuser {
  currentuser {
    _id
    first_name
    last_name
    second_name
    profilePhoto
    phone_number
    country {
      _id
      country_name
      image
      status
    }
    fundraisers {
      amount
      _id
      donatedAmount
      story
      image
    }
    postal_code
    donationRequest {
      _id
      amount
      donatedAmount
      status
      product {
        _id
        product_name
        quantity
        availabelQuantity
        supplier {
          _id
          email
          phone_number
          supplier_name
          category {
            _id
            category_name
          }
        }
      }
      donations {
        _id
        amount
        status
        donar {
          first_name
          last_name
          profilePhoto
          phone_number
          country {
            country_name
          }
          email
        }
        donationRequests {
          _id
          amount
          donatedAmount
          product {
            product_name
          }
          category {
            category_name
          }
          member {
            first_name
            last_name
            country {
              country_name
            }
          }
        }
      }
      category {
        _id
        category_name
      }
      member {
        _id
        first_name
        email
        last_name
        phone_number
        profilePhoto
        country {
          country_name
        }
      }
      shipped_date
      rejected_date
      process_date
      shippingAddress
      closed_date
      createdAt
      updatedAt
      quantity
      video
      image
    }
    donations {
      _id
      amount
      status
      donationRequests {
        donatedAmount
        amount
        request_code
        _id
        category {
          category_name
        }
        product {
          product_name
          _id
        }
      }
      donar {
        _id
        email
        first_name
        last_name
        phone_number
        profilePhoto
      }
      donation_code
    }
    zip_code
    school_name
    email
    street
    role {
      _id
      role_name
    }
    createdAt
    updatedAt
  }
}
`
export const CURRENTUSER_QUERY = gql`
query Oneuser($userId: ID!) {
  oneuser(userId: $userId) {
    _id
    first_name
    last_name
    second_name
    profilePhoto
    phone_number
    postal_code
    zip_code
    school_name
    email
    street
    role {
      _id
      role_name
      createdAt
      updatedAt
    }
    createdAt
    updatedAt
    
  }
}
`
export const ALL_USERS_QUERY = gql`
  query AllUsersQuery {
    allUsers {
      id
      username
      email
    }
  }
`
export const ALL_ATTRIBUTES_QUERY = gql`
query Query {
  attributes {
    attribute_name
    _id
  }
}
`

export const ADD_ATTRIBUTE_MUTATION = gql`
mutation CreateAttribute($attributeName: String!) {
  createAttribute(attribute_name: $attributeName) {
    attribute_name
  }
}
`
export const DELETE_ATTRIBUTE_MUTATION = gql`
mutation DeleteAttribute($attributeId: ID!) {
  deleteAttribute(attributeId: $attributeId) {
    _id
  }
}
`
export const EDIT_ATTRIBUTE_MUTATION = gql`
mutation Updateattribute($input: updateAttribute) {
  updateattribute(input: $input) {
    _id
    attribute_name
  }
}
`

//categories
export const ALL_CATEGORIES_QUERY = gql`
query Categories {
  categories {
    _id
    category_name
  }
}
`
export const ADD_CATEGORY_MUTATION = gql`
mutation Mutation($categoryName: String!) {
  createCategory(category_name: $categoryName) {
    category_name
  }
}
`
export const DELETE_CATEGORY_MUTATION = gql`
mutation Mutation($categoryId: ID!) {
  deleteCategory(categoryId: $categoryId) {
    _id
  }
}
`
export const EDIT_CATEGORY_MUTATION = gql`
mutation Updatecategory($input: updateCategory) {
  updatecategory(input: $input) {
    _id
    category_name
  }
}
`

//donations
export const ALL_DONATIONS_QUERY = gql`
query Donations {
  donations {
    _id
    createdAt
    donar {
      _id
      first_name
      last_name
      profilePhoto
      role {
        _id
        role_name
      }
    }
    amount
    status
    donationRequests {
      _id
      request_code
      amount
      donatedAmount
      status
      quantity
      category {
        _id
        category_name
      }
      product {
        _id
        product_name
        availabelQuantity
        quantity
        status
        unitPrice
        category {
          _id
          category_name
        }
        supplier {
          _id
          phone_number
          postal_code
        }
      }
      member {
        _id
        first_name
        last_name
        second_name
        profilePhoto
        phone_number
        postal_code
        email
        street
        role {
          _id
          role_name
        }
        gender
      }
      shipped_date
      rejected_date
      process_date
      shippingAddress
      closed_date
      image
      video
    }
    donation_code
  }
}
`
export const ADD_DONATION_MUTATION = gql`
mutation CreateDonation($amount: String!, $donationRequestId: ID!, $donarId: ID!) {
  createDonation(amount: $amount, donationRequestId: $donationRequestId, donarId: $donarId) {
    _id
  }
}
`
export const DELETE_DONATION_MUTATION = gql`
mutation DeleteDonation($donationId: ID!) {
  deleteDonation(donationId: $donationId) {
    _id
  }
}
`
export const EDIT_DONATION_MUTATION = gql`
mutation Updatedonation($input: updateDonation) {
  updatedonation(input: $input) {
    _id
  }
}
`
export const EDIT_FUNDRAISER_DONATION_MUTATION = gql`
mutation UpdateDonationFundraiser($input: updateDonationFundraiser) {
  updateDonationFundraiser(input: $input) {
    _id
  }
}
`

export const ALL_SYTEMUSERS_MUTATION = gql`
query Allusers {
  allusers {
    _id
    first_name
    last_name
    second_name
    profilePhoto
    phone_number
    county {
      _id
      county_name
      country {
        _id
        country_name
      }
    }
    postal_code
    zip_code
    school_name
    email
    street
    role {
      _id
      role_name
    }
    createdAt
    updatedAt
    country {
      _id
      country_name
    }
  }
}
`
//countries
export const ALL_COUNTRIES_QUERY = gql`
query Allcountries {
  allcountries {
    country_name
    _id
    status
  }
}
`
export const EDIT_COUNTRY_MUTATION = gql`
mutation Updatecountry($input: updateCountry) {
  updatecountry(input: $input) {
    _id
    country_name
    createdAt
  }
}
`
export const ADD_COUNTRY_MUTATION = gql`
mutation CreateCountry($countryName: String!) {
  createCountry(country_name: $countryName) {
    _id
    country_name
    status
    image
  }
}
`
//suplliers
export const ALL_SUPPLIERS_QUERY = gql`
query Suppliers {
  suppliers {
    _id
    category {
      _id
      category_name
    }
    payment {
      _id
      payment_name
    }
    supplier_name
    phone_number
    postal_code
    zip_code
    street
    email
    products {
      _id
      product_name
      status
      quantity
      unitPrice
      availabelQuantity      
    }
  }
}
`
export const EDIT_SUPPLIER_MUTATION = gql`
mutation Updatesupplier($input: updateSupplier) {
  updatesupplier(input: $input) {
    _id
    phone_number
    supplier_name
  }
}
`
export const ADD_SUPPLIER_MUTATION = gql`
mutation CreateSupplier($supplierName: String!, $paymentId: ID!, $categoryId: ID!, $email: String!, $phoneNumber: String!, $postalCode: String!, $street: String!) {
  createSupplier(supplier_name: $supplierName, paymentId: $paymentId, categoryId: $categoryId, email: $email, phone_number: $phoneNumber, postal_code: $postalCode, street: $street) {
    products {
      _id
      status
    }
  }
}
`
export const DELETE_SUPPLIER_MUTATION = gql`
mutation DeleteSupplier($supplierId: ID!) {
  deleteSupplier(supplierId: $supplierId) {
    _id
  }
}
`
//Roles
export const ADD_ROLE_MUTATION = gql`
mutation CreateRole($roleName: String!) {
  createRole(role_name: $roleName) {
    _id
    role_name
  }
}
`

export const ALL_ROLES_MUTATION = gql`
query AllRoles {
  allRoles {
    _id
    role_name
  }
}
`
//payments

export const ALL_PAYMENTS_QUERY = gql`
query Payments {
  payments {
    _id
    payment_name
  }
}
`
export const ADD_PAYMENT_MUTATION = gql`
mutation CreatePayment($paymentName: String!) {
  createPayment(payment_name: $paymentName) {
    _id
    payment_name
  }
}
`
export const DELETE_PAYMENT_MUTATION = gql`
mutation DeletePayment($paymentId: ID!) {
  deletePayment(paymentId: $paymentId) {
    _id
  }
}
`
export const EDIT_PAYMENT_MUTATION = gql`
mutation Updatepayment($input: updatePayment) {
  updatepayment(input: $input) {
    _id
    payment_name
  }
}
`
export const ALL_DONORS_QUERY = gql`
query FilterUsers($roleId: String!, $status: String!) {
  filterUsers(roleId: $roleId, status: $status) {
    _id
    first_name
    last_name
    second_name
    phone_number
    postal_code
    zip_code
    school_name
    profilePhoto
    email
    street
    country {
      country_name
      _id
    }
    role {
      _id
      role_name
    }
  }
}
`
export const ADD_USER_MUTATION = gql`
mutation CreateUser($createAcc: CreateAcc) {
  createUser(createAcc: $createAcc) {
    _id
    first_name
    last_name
    phone_number
  }
}
`
export const EDIT_USER_MUTATION = gql`
mutation Updateuser($input: updateAcc) {
  updateuser(input: $input) {
    profilePhoto
    phone_number
    last_name
    first_name
  }
}
`
export const DELETE_USER_MUTATION = gql`
mutation DeleteUser($id: ID!) {
  deleteUser(_id: $id) {
    _id
  }
}
`
//faqs

export const ALL_FAQS_QUERY = gql`
query Faqs {
  faqs {
    _id
    question
    answer
    status
  }
}
`
export const ADD_FAQ_MUTATION = gql`
mutation CreateFaq($question: String!, $answer: String!) {
  createFaq(question: $question, answer: $answer) {
    _id
    question
    answer
    status
  }
}
`
export const EDIT_FAQ_MUTATION = gql`
mutation Updatefaqs($input: updateFaq) {
  updatefaqs(input: $input) {
    _id
    question
    answer
    status
  }
}
`
export const DELETE_FAQ_MUTATION = gql`
mutation Deletefaq($faqId: ID!) {
  deletefaq(faqId: $faqId) {
    question
    _id
    answer
  }
}
`

//donations
export const ALL_DONATIONREQUESTS_QUERY = gql`
query DonationRequests {
  donationRequests {
    _id
    request_code
    amount
    donatedAmount
    status
    quantity
    category {
      _id
      category_name
    }
    product {
      _id
      availabelQuantity
      product_name
      quantity
      supplier {
        _id
        supplier_name
      }
      unitPrice
    }
    donations {
      _id
      amount
      donar {
        _id
        email
        first_name
      }
      donation_code
      fundraiser {
        _id
        amount
        donatedAmount
        story
        image
        video
      }
      status
      createdAt
      updatedAt
    }
    member {
      _id
      last_name
      first_name
      email
    }
    member {
      _id
      first_name
      email
      last_name
      gender
      phone_number
      role {
        _id
        role_name
      }
    }
    shipped_date
    rejected_date
    process_date
    shippingAddress
    closed_date
    image
    video
  }
}
`
export const ADD_DONATIONREQUEST_MUTATION = gql`
mutation CreateDonationRequest($amount: String!, $productId: ID!, $memberId: ID!, $categoryId: ID!, $shippingAddress: String, $quantity: String!) {
  createDonationRequest(amount: $amount, productId: $productId, memberId: $memberId, categoryId: $categoryId, shippingAddress: $shippingAddress, quantity: $quantity) {
    amount
    quantity
    product {
      _id
    }
    member {
      _id
    }
    category {
      _id
    }
    shippingAddress
  }
}
`
export const DELETE_DONATIONREQUEST_MUTATION = gql`
mutation DeleteDonationRequest($donationRequestId: ID!) {
  deleteDonationRequest(donationRequestId: $donationRequestId) {
    _id
  }
}
`

export const EDIT_DONATIONREQUEST_MUTATION = gql`
mutation Updatedonationrequest($input: updateDonationRequest) {
  updatedonationrequest(input: $input) {
    _id
  }
}
`
export const EDIT_FUNDRAISER_MUTATION = gql`
mutation UpdateFundraiser($input: updateFundraiserRequest) {
  updateFundraiser(input: $input) {
    _id
  }
}
`
export const DONATE_FUNDRAISER_MUTATION = gql`
mutation DonateToFundraiser($amount: String!, $fundraiserId: ID!, $donarId: ID!) {
  donateToFundraiser(amount: $amount, fundraiserID: $fundraiserId, donarId: $donarId) {
    _id
    fundraiser {
      _id
    }
    donar {
      _id
    }
  }
}
`
export const DELETE_FUNDRAISER_MUTATION = gql`
mutation DeleteFundraiser($fundraiserId: ID!) {
  deleteFundraiser(fundraiserId: $fundraiserId) {
    _id
  }
}
`
//products
export const ALL_PRODUCTS_QUERY = gql`
query Products {
  products {
    _id
    product_name
    category {
      _id
      category_name
    }
    unitPrice
    quantity
    availabelQuantity
    status
    supplier {
      _id
      category {
        _id
        category_name
      }
      supplier_name
      phone_number
      postal_code
      zip_code
      street
      email
      products {
        _id
        product_name
        quantity
        unitPrice
      }
      payment {
        _id
        payment_name
      }
    }
  }
}

`
export const ADD_PRODUCT_MUTATION = gql`
mutation CreateProduct($productName: String!, $categoryId: ID!, $supplierId: ID!, $quantity: String, $unitPrice: Float) {
  createProduct(product_name: $productName, categoryId: $categoryId, supplierID: $supplierId, quantity: $quantity, unitPrice: $unitPrice) {
    _id
  }
}
`
export const DELETE_PRODUCT_MUTATION = gql`
mutation DeleteProduct($productId: ID!) {
  deleteProduct(productId: $productId) {
    _id
  }
}
`
export const EDIT_PRODUCT_MUTATION = gql`
mutation Updateproduct($input: updateProduct) {
  updateproduct(input: $input) {
    _id
    product_name
    status
    quantity
    unitPrice
    availabelQuantity
  }
}
`
//cities
export const ALL_CITIES_QUERY = gql`
query Allcities {
  allcities {
    _id
    city_name
    country {
      _id
      country_name
    }
    status
  }
}
`
export const ADD_CITY_MUTATION = gql`
mutation CreateCity($cityName: String!, $countryId: ID!) {
  createCity(city_name: $cityName, countryID: $countryId) {
    _id
    city_name
  }
} 
`
export const DELETE_CITY_MUTATION = gql`
mutation DeleteCity($cityId: ID!) {
  deleteCity(cityId: $cityId) {
    _id
  }
}
`
export const EDIT_CITY_MUTATION = gql`
mutation Updatecity($input: updateCity) {
  updatecity(input: $input) {
    _id
    city_name
  }
}
`

//county
export const ALL_COUNTIES_QUERY = gql`
query Allcounties {
  allcounties {
    _id
    country {
      _id
      country_name
      image
    }
    county_name
    status
  }
}
`
export const ADD_COUNTY_MUTATION = gql`
mutation CreateCounty($countyName: String!, $countryId: ID!) {
  createCounty(county_name: $countyName, countryID: $countryId) {
    _id
    county_name
    status
    country {
      _id
      country_name
      image
    }
  }
} 
`
export const DELETE_COUNTY_MUTATION = gql`
mutation DeleteCounty($countyId: ID!) {
  deleteCounty(countyId: $countyId) {
    _id
  }
}
`
export const EDIT_COUNTY_MUTATION = gql`
mutation Updatecounty($input: updateCounty) {
  updatecounty(input: $input) {
    status
    county_name
    _id
  }
}
`

//tax
export const ALL_TAX_QUERY = gql`
query Taxes {
  taxes {
    _id
    status
    tax
    country {
      _id
      country_name
      image
    }
  }
}
`
export const ADD_TAX_MUTATION = gql`
mutation CreateTax($tax: String!, $countryId: ID!) {
  createTax(tax: $tax, countryId: $countryId) {
    _id
    tax
  }
} 
`
export const DELETE_TAX_MUTATION = gql`
mutation DeleteTax($taxId: ID!) {
  deleteTax(taxId: $taxId) {
    _id
  }
}
`
export const EDIT_TAX_MUTATION = gql`
mutation Updatetax($input: updateTax) {
  updatetax(input: $input) {
    _id
    tax
  }
}
`
//setting
export const ALL_SETTINGS_QUERY = gql`
query SystemSettings {
  systemSettings {
    _id
    site
    sitetitle
    url
    metaTagInfo
    copyrightText
    administratorEmail
    controlPanelTitle
  }
}
`
export const ADD_SETTING_MUTATION = gql`
mutation CreateSystemSettings($site: String!, $sitetitle: String!, $url: String!, $metaTagInfo: String!, $copyrightText: String!, $administratorEmail: String!, $controlPanelTitle: String!) {
  createSystemSettings(site: $site, sitetitle: $sitetitle, url: $url, metaTagInfo: $metaTagInfo, copyrightText: $copyrightText, administratorEmail: $administratorEmail, controlPanelTitle: $controlPanelTitle) {
    _id
    administratorEmail
    controlPanelTitle
    copyrightText
    metaTagInfo
    site
    sitetitle
    url
  }
}
`
export const DELETE_SETTING_MUTATION = gql`
mutation DeleteSystemSettings($settingId: ID!) {
  deleteSystemSettings(settingId: $settingId) {
    _id
  }
}
`
export const EDIT_SETTING_MUTATION = gql`
mutation Updatesystemsettings($input: updateSystemSettings) {
  updatesystemsettings(input: $input) {
    _id
  }
}
`
//dashboard
export const DASHBOARD_QUERY = gql`
query AllDonationRequests {
  allDonationRequests {
    total
    amount
    totalDonations
    monthsTotal
    monthsTotalRequests
    monthsDonations {
      _id
      donar {
        first_name
        last_name
        profilePhoto
        phone_number
        country {
          country_name
        }
        email
      }
      amount
    }
    monthsDonationRequests {
      _id
      amount
      donatedAmount
      status
      member {
        first_name
        last_name
        profilePhoto
        phone_number
        country {
          country_name
        }
        email
      }
      product {
        product_name
      }
      category {
        category_name
        _id
      }
    }
    topDonations {
      donar {
        first_name
        last_name
        profilePhoto
        phone_number
        country {
          country_name
        }
        email
      }
      amount
      donationRequests {
        request_code
      }
      fundraiser {
        request_code
      }
    }
  }
}
`
export const USER_DASHBOARD_QUERY = gql`
query UserDashboard {
  userDashboard {
    total
    total
    amount
    totalDonations
    monthsTotal
    monthsTotalFundraiser
    monthsTotalFundraiserDonated
    monthsTotalRequestDonated
    monthsTotalRequests
    monthsDonations {
      _id
      donar {
        first_name
        last_name
        profilePhoto
        phone_number
        country {
          country_name
        }
        email
      }
      amount
    }
    monthsDonationRequests {
      _id
      amount
      donatedAmount
      status
      request_code
      member {
        first_name
        last_name
        profilePhoto
        phone_number
        country {
          country_name
        }
        email
      }
      product {
        product_name
      }
      category {
        category_name
        _id
      }
    }
    topDonations {
      donar {
        first_name
        last_name
        profilePhoto
        phone_number
        country {
          country_name
        }
        email
      }
      amount
      donationRequests {
        request_code
      }
      fundraiser {
        request_code
      }
    }
    monthsFundraiser {
      _id
      request_code
      amount
      donatedAmount
      status
      story
      image
      member {
        first_name
        last_name
        profilePhoto
        country {
          _id
        }
      }
    }
  }
}
`

export const REQUESTSTATUS_QUERY = gql`
query DonationRequestsPerStatus($status: String!) {
  donationRequestsPerStatus(status: $status) {
    _id
    request_code
    amount
    donatedAmount
    status
    product {
      product_name
      _id
      category {
        category_name
        _id
      }
      unitPrice
      quantity
      availabelQuantity
    }
    category {
      category_name
    }
    donations {
      createdAt
      donar {
        first_name
        last_name
        profilePhoto
        county {
          county_name
        }
      }
      amount
    }
    member {
      first_name
      last_name
      profilePhoto
      phone_number
      email
      country {
        country_name
      }
    }
  }
}
`

export const REQUEST_USER_STATUS_QUERY = gql`
query donationRequestsPerStatusUser($status: String!) {
  donationRequestsPerStatusUser(status: $status) {
    _id
    request_code
    amount
    donatedAmount
    status
    shippingAddress
    quantity
    createdAt
    product {
      product_name
      _id
      category {
        category_name
        _id
      }
      unitPrice
      quantity
      availabelQuantity
    }
    category {
      category_name
      _id
    }
    donations {
      donar {
        first_name
        last_name
        profilePhoto
        county {
          county_name
        }
      }
      amount
      createdAt
    }
    member {
      first_name
      last_name
      profilePhoto
      phone_number
      email
      country {
        country_name
      }
    }
  }
}
`
export const FUNDRAISER_USER_STATUS_QUERY = gql`
query FundraisersPerStatusUser($status: String!) {
  fundraisersPerStatusUser(status: $status) {
    _id
    request_code
    amount
    donatedAmount
    status
    story
    image
    video
    createdAt
    donations {
      _id
      donar {
        first_name
        last_name
        profilePhoto
        county {
          county_name
        }
      }
      amount
    }
    member {
      _id
      first_name
      last_name
      second_name
      profilePhoto
      phone_number
      country {
        country_name
      }
    }
  }
}
`
export const PRODUCT_BY_CATEGORY_QUERY = gql`
query ProductByCategory($categoryId: ID!) {
  productByCategory(categoryId: $categoryId) {
    product_name
    _id
    unitPrice
    quantity
    availabelQuantity
    status
    category {
      category_name
      _id
    }
  }
}
`
export const FILTER_DONATION_QUERY = gql`
query FilteredDonations($status: String!) {
  filteredDonations(status: $status) {
    _id
    amount
    createdAt
    donation_code
    status
    donar {
      country {
        country_name
        _id
      }
      last_name
      first_name
      email
    }
    donationRequests {
      _id
      amount
      category {
        _id
        category_name
      }
      donatedAmount
      product {
        _id
        product_name
      }
      request_code
    }
    fundraiser {
      amount
      donatedAmount
      image
      member {
        first_name
        last_name
        _id
        country {
          country_name
          _id
        }
        profilePhoto
      }
      story
      createdAt
      request_code
    }
  }
}
`
export const REQUEST_BY_CATEGORY_BY_STATUS_BY_USER = gql`
query DonationRequestsPerCategoryUser($categoryId: ID!, $status: String!) {
  donationRequestsPerCategoryUser(categoryID: $categoryId, status: $status) {
    _id
    amount
    category {
      category_name
      _id
    }
    donatedAmount
    donations {
      _id
      amount
      createdAt
      donar {
        _id
        first_name
        last_name
        second_name
        country {
          country_name
          _id
        }
      }
      donation_code
    }
    member {
      _id
      country {
        country_name
        _id
      }
      first_name
      last_name
      profilePhoto
      phone_number
    }
    story
    video
    shippingAddress
    request_code
    product {
      _id
      category {
        _id
        category_name
      }
      product_name
      unitPrice
      availabelQuantity
    }
    image
    status
    rejected_date
    shipped_date
    process_date
    closed_date
  }
}
`
export const CREATE_FUNDRAISER = gql`
mutation CreateFundraiser($amount: String!, $memberId: ID!, $story: String!) {
  createFundraiser(amount: $amount, memberId: $memberId, story: $story) {
    amount
    member {
      _id
    }
    story
  }
}
`
export const DELETE_FUNDRAISER = gql`
mutation DeleteFundraiser($fundraiserId: ID!) {
  deleteFundraiser(fundraiserId: $fundraiserId) {
    _id
  }
}
`
export const CURRENT_USER_DONATIONS = gql`
query Currentuser {
  currentuser {
    _id
    donations {
      donar {
        first_name
        last_name
        profilePhoto
        phone_number
        country {
          country_name
          _id
        }
      }
      amount
      donation_code
      status
      createdAt
      fundraiser {
        _id
        amount
        donatedAmount
        image
        status
        member {
          first_name
          last_name
          _id
          country {
            country_name
            _id
          }
          profilePhoto
        }
      }
      donationRequests {
        _id
        request_code
        amount
        donatedAmount
        status
        
        product {
          product_name
          _id
        }
        member {
          first_name
          last_name
          profilePhoto
          country {
            country_name
          }
        }
      }
      
    }
  }
}
`

export const CREATE_BANKING_MUTATION = gql`
mutation CreateBankBilling($bankName: String!, $branch: String!, $accountName: String!, $accountNumber: String!, $swiftCode: String!) {
  createBankBilling(bank_name: $bankName, branch: $branch, account_name: $accountName, account_number: $accountNumber, swift_code: $swiftCode, userID: $userId) {
    account_name
    account_number
    bank_name
    branch
    swift_code
    user {
      _id
    }
  }
}
`
export const BANK_BILLING_QUERY = gql`
query BankBillings {
  bankBillings {
    _id
    account_name
    account_number
    bank_name
    branch
    swift_code
    user {
      _id
      first_name
      last_name
      phone_number
      email
    }
  }
}
`
export const MPESA_DETAILS_MUTATION = gql`
mutation CreateMpesaDetails($account: String!, $userId: ID) {
  createMpesaDetails(account: $account, userID: $userId) {
    account
    user {
      _id
    }
  }
}
`
export const MPESA_DETAILS_QUERY = gql`
query MpesaDetails {
  mpesaDetails {
    _id
    account
    user {
      email
      first_name
      last_name
      phone_number
      _id
    }
  }
}
`
export const FUNDRAISER_BY_STATUS_QUERY = gql`
query FundraisersPerStatus($status: String!) {
  fundraisersPerStatus(status: $status) {
    _id
    amount
    createdAt
    image
    request_code
    status
    story
    donatedAmount
    video
    member {
      _id
      first_name
      last_name
      phone_number
      email
      country {
        country_name
        _id
      }
      profilePhoto
    }
    donations {
      _id
      amount
      donar {
        _id
        first_name
        email
        phone_number
        last_name
      }
    }
  }
}
`
export const FUNDRAISER_DONATION_USER_QUERY = gql`
query FundraiserWithDonations {
  fundraiserWithDonationsPerUser {
    amount
    createdAt
    donatedAmount
    image
    status
    story
    video
    member {
      _id
      first_name
      last_name
      country {
        _id
        country_name
      }
      profilePhoto
    }
    donations {
      _id
      amount
      donation_code
      status
      donar {
        _id
        first_name
        last_name
        profilePhoto
        country {
          _id
          country_name
        }
      }
    }
    request_code
  }
}
`
export const DONATIONREQUEST_DONATION_USER_QUERY = gql`
query DonationRequestsWithDonationsPerUser {
  donationRequestsWithDonationsPerUser {
    _id
    amount
    closed_date
    donatedAmount
    category {
      category_name
      _id
    }
    product {
      _id
      product_name
    }
    member {
      first_name
      last_name
      country {
        country_name
        _id
      }
      profilePhoto
    }
    createdAt
    donations {
      _id
      amount
      donation_code
      status
      donar {
        last_name
        first_name
        country {
          country_name
          _id
        }
        profilePhoto
      }
      createdAt
    }
  }
}
`
export const FUNDRAISER_WITH_DONATION_QUERY = gql`
query FundraiserWithDonations {
  fundraiserWithDonations {
    amount
    createdAt
    donatedAmount
    image
    status
    story
    video
    member {
      _id
      first_name
      last_name
      country {
        _id
        country_name
      }
      profilePhoto
    }
    donations {
      _id
      amount
      donation_code
      status
      donar {
        _id
        first_name
        last_name
        profilePhoto
        country {
          _id
          country_name
        }
      }
    }
    request_code
  }
}
`
// export const DONATIONREQUESTS_WITH_DONATION_QUERY = gql`
// query DonationRequestsWithDonations {
//   donationRequestsWithDonations {
//     _id
//     amount
//     closed_date
//     donatedAmount
//     category {
//       category_name
//       _id
//     }
//     product {
//       _id
//       product_name
//     }
//     member {
//       first_name
//       last_name
//       country {
//         country_name
//         _id
//       }
//       profilePhoto
//     }
//     createdAt
//     donations {
//       _id
//       amount
//       donation_code
//       status
//       donar {
//         last_name
//         first_name
//         country {
//           country_name
//           _id
//         }
//         profilePhoto
//       }
//       createdAt
//     }
//   }
// }
// `
export const DONATIONREQUESTS_WITH_DONATION_QUERY = gql`
query DonationRequestsWithDonations {
  donationRequestsWithDonations {
    _id
    request_code
    amount
    donatedAmount
    status
    quantity
    category {
      _id
      category_name
    }
    donations {
      _id
      amount
      donar {
        _id
        email
        first_name
        gender
        last_name
        phone_number
      }
      donation_code
      fundraiser {
        _id
        amount
        donatedAmount
        story
        request_code
      }
      status
    }
    shipped_date
    rejected_date
    process_date
    shippingAddress
    closed_date
    image
    video
    createdAt
    updatedAt
    product {
      _id
      availabelQuantity
      product_name
      quantity
      unitPrice
      supplier {
        _id
        email
        phone_number
        supplier_name
      }
    }
  }
}
`